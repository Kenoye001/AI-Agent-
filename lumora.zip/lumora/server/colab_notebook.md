# Run a free video generator on Google Colab

Paste each block into its own cell in a new Colab notebook. Before you start, choose
**Runtime > Change runtime type > T4 GPU**.

**Cell 1: install**
```python
!pip install -q fastapi uvicorn pydantic pillow imageio imageio-ffmpeg
!pip install -q -U diffusers transformers accelerate sentencepiece protobuf
!wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cloudflared && chmod +x cloudflared
```

**Cell 2: upload `lumora_server.py`** (from this project's `server` folder)
```python
from google.colab import files
files.upload()   # choose lumora_server.py
```

**Cell 3: start the server and a public tunnel, then tell Lumora where it is**

Use the same two secrets you set in Supabase (`GENERATOR_TOKEN` and `REGISTER_KEY`, see the README, phase 3).
Leave `SUPABASE_URL` empty to skip registering and paste the printed address into Settings > My own server instead.
```python
import os, subprocess, threading, time, re, requests

GENERATOR_TOKEN = "same-value-as-the-GENERATOR_TOKEN-secret"
REGISTER_KEY    = "same-value-as-the-REGISTER_KEY-secret"
SUPABASE_URL    = "https://YOUR-PROJECT-REF.supabase.co"   # or "" to skip
SUPABASE_ANON   = ""                                        # only if the register call is rejected

os.environ["LUMORA_TOKEN"] = GENERATOR_TOKEN
os.environ["LUMORA_MAX_SIDE"] = "512"            # raise to 704 if you have memory to spare

threading.Thread(target=lambda: subprocess.run(
    ["uvicorn", "lumora_server:app", "--host", "0.0.0.0", "--port", "8000"]), daemon=True).start()

time.sleep(2)
tunnel = subprocess.Popen(["./cloudflared", "tunnel", "--url", "http://localhost:8000"],
                          stderr=subprocess.PIPE, text=True)
url = None
for line in tunnel.stderr:
    m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
    if m:
        url = m.group(0); break
print("Generator address:", url)

if SUPABASE_URL and url:
    # Wait for the model to finish loading, then register (the server answers /health once it is ready).
    for _ in range(120):
        try:
            if requests.get(url + "/health", headers={"Authorization": f"Bearer {GENERATOR_TOKEN}"}, timeout=5).ok: break
        except Exception: pass
        time.sleep(5)
    headers = {"x-register-key": REGISTER_KEY}
    if SUPABASE_ANON: headers["Authorization"] = f"Bearer {SUPABASE_ANON}"
    r = requests.post(f"{SUPABASE_URL}/functions/v1/register-generator", headers=headers, json={"url": url})
    print("Registered with Lumora:", r.status_code, r.text)
```

The first start downloads the model (several GB) and can take 5 to 10 minutes. The cell registers the
generator once the model is loaded. In Lumora, choose **Settings > Lumora cloud** and use
**Check that it is online**. (If you registered nothing, use **My own server** and **Test connection**.)

## What to expect

- A 5 second clip at 512 px takes roughly 3 to 8 minutes on a free T4.
- Colab disconnects after a few hours or when idle. When it does, Lumora shows the cloud generator as
  offline and disables Generate (nobody is charged). Run the cells again: the new tunnel address is
  registered automatically. Only one clip renders at a time, so a batch of 4 takes four times as long.
- Kaggle works too (30 free GPU hours a week). Use the same cells in a Kaggle notebook with
  Internet turned on.
- Running locally on an NVIDIA GPU with 8 GB or more: `pip install` the same packages,
  run `uvicorn lumora_server:app --port 8000`, and use `http://localhost:8000` as the address.

## Using a different model

`lumora_server.py` is the only file to change. Keep the three routes (`/health`,
`/generate`, `/jobs/{id}`) and the web app will work with any model, such as Wan 2.1 or CogVideoX.
