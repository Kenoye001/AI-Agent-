"""
Lumora generator server: runs an open-source video model (LTX-Video) behind the small
HTTP contract that Lumora's "My own server" setting expects.

Runs on a free Google Colab / Kaggle GPU (a T4 with 15-16 GB is enough at the default sizes).
See server/colab_notebook.md for the exact cells to paste.

NOTE: written against the diffusers LTX pipelines. It has not been run on a GPU in the
environment where this project was built, so expect to adjust model settings for your GPU.

Env vars:
  LUMORA_TOKEN   optional bearer token the web app must send
  LUMORA_MODEL   Hugging Face model id (default Lightricks/LTX-Video)
  LUMORA_MAX_SIDE  longest video side in pixels (default 512; raise on bigger GPUs)
"""

import os
import threading
import time
import uuid
from pathlib import Path
import base64
import io

import torch
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from diffusers import LTXPipeline, LTXImageToVideoPipeline
from diffusers.utils import export_to_video
from PIL import Image

TOKEN = os.environ.get("LUMORA_TOKEN", "")
MODEL = os.environ.get("LUMORA_MODEL", "Lightricks/LTX-Video")
MAX_SIDE = int(os.environ.get("LUMORA_MAX_SIDE", "512"))
FPS = 24
SEGMENT = 5  # seconds per generated piece
MAX_SECONDS = 60
OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

print("Loading model, this takes a few minutes the first time...")
t2v = LTXPipeline.from_pretrained(MODEL, torch_dtype=torch.bfloat16)
t2v.enable_model_cpu_offload()  # keeps a 16 GB GPU from running out of memory
i2v = LTXImageToVideoPipeline(**t2v.components)
print("Model ready.")

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

jobs: dict[str, dict] = {}
lock = threading.Lock()  # one generation at a time on a single GPU


class Req(BaseModel):
    prompt: str
    negative_prompt: str = ""
    aspect: str = "16:9"
    duration: int = 5
    seed: int = 0
    image: str | None = None
    # accepted for forward compatibility, unused here
    style: str | None = None
    camera: str | None = None
    model: str | None = None
    resolution: str | None = None


def check(auth: str | None):
    if TOKEN and auth != f"Bearer {TOKEN}":
        raise HTTPException(401, "Wrong or missing access token.")


def size_for(aspect: str):
    a, b = (float(x) for x in aspect.split(":"))
    r = a / b
    w, h = (MAX_SIDE, MAX_SIDE / r) if r >= 1 else (MAX_SIDE * r, MAX_SIDE)
    snap = lambda n: max(64, int(round(n / 32)) * 32)  # the model needs multiples of 32
    return snap(w), snap(h)


def frames_for(seconds: int):
    n = max(9, int(seconds * FPS))
    return (n - 1) // 8 * 8 + 1  # the model needs 8k + 1 frames


def work(job_id: str, r: Req):
    job = jobs[job_id]
    try:
        with lock:
            job["status"] = "running"
            w, h = size_for(r.aspect)
            steps = 30
            gen = torch.Generator("cuda").manual_seed(r.seed)

            # Long clips are made as a chain of pieces of at most SEGMENT seconds. Each later piece
            # starts from the last frame of the one before, so the shot continues.
            total = max(1, min(int(r.duration), MAX_SECONDS))
            pieces = []
            remaining = total
            while remaining > 0:
                pieces.append(min(SEGMENT, remaining))
                remaining -= SEGMENT
            frames, img = [], None
            if r.image:
                raw = base64.b64decode(r.image.split(",", 1)[-1])
                img = Image.open(io.BytesIO(raw)).convert("RGB").resize((w, h))
            for n, secs in enumerate(pieces):
                def tick(pipe, i, t, kw, n=n):
                    job["progress"] = min(0.95, (n + (i + 1) / steps) / len(pieces))
                    return kw

                common = dict(
                    prompt=r.prompt,
                    negative_prompt=r.negative_prompt or "worst quality, inconsistent motion, blurry, jittery, distorted",
                    width=w,
                    height=h,
                    num_frames=frames_for(secs),
                    num_inference_steps=steps,
                    generator=gen,
                    callback_on_step_end=tick,
                )
                part = (i2v(image=img, **common) if img is not None else t2v(**common)).frames[0]
                frames.extend(part if n == 0 else part[1:])  # drop the repeated start frame
                img = part[-1].convert("RGB") if hasattr(part[-1], "convert") else Image.fromarray(part[-1]).convert("RGB")
                torch.cuda.empty_cache()
            path = OUT / f"{job_id}.mp4"
            export_to_video(frames, str(path), fps=FPS)
        job.update(status="done", progress=1.0, video_url=f"/files/{job_id}.mp4")
    except Exception as e:  # report the real reason to the web app
        job.update(status="failed", error=str(e))
    finally:
        torch.cuda.empty_cache()


@app.get("/health")
def health(authorization: str | None = Header(None)):
    check(authorization)
    return {"ok": True, "model": MODEL, "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}


@app.post("/generate")
def generate(r: Req, authorization: str | None = Header(None)):
    check(authorization)
    job_id = uuid.uuid4().hex[:12]
    jobs[job_id] = {"status": "queued", "progress": 0.0, "created": time.time()}
    threading.Thread(target=work, args=(job_id, r), daemon=True).start()
    return {"job_id": job_id}


@app.get("/jobs/{job_id}")
def job(job_id: str, authorization: str | None = Header(None)):
    check(authorization)
    if job_id not in jobs:
        raise HTTPException(404, "Unknown job.")
    return jobs[job_id]


@app.get("/files/{name}")
def files(name: str, authorization: str | None = Header(None)):
    check(authorization)
    p = (OUT / name).resolve()
    if p.parent != OUT.resolve() or not p.exists():
        raise HTTPException(404, "No such file.")
    return FileResponse(p, media_type="video/mp4")
