# Lumora

A Higgsfield-style AI video studio built with React, Vite and Tailwind. All branding, copy and
visuals are original. Everything runs free, in the browser.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/ (uses hash routing, so any static host works)
```

Click **Try the demo account** on the login page to get straight in.

## What is in it

| Area | What works |
| --- | --- |
| Landing | Animated hero, sample strip, features, how it works, free-forever note |
| Explore | 16 example clips, category filter, search, detail view, remix |
| Studio | Text to video, image to video, 8 looks, 13 camera moves, 5 shapes, 4 lengths, 2 models, 1-4 clips per run, negative prompt, seed, live credit cost, queue with progress and cancel |
| Library | Everything you made, favorites, filters, sort, download, delete |
| Credits | Explains the free daily credits, the two models and how refunds work |
| Accounts | Sign up, log in, demo account, daily credit refill, refunds on cancel or failure |
| Settings | Choose Preview, Lumora cloud or your own generator; test the connection; delete account |

## Two modes of generation

**Preview (default, no setup).** The clip is drawn live in your browser from your prompt, look
and camera move. It is a stand-in for the real thing so the whole app can be used and demoed
without a GPU. Downloads record the preview to a WebM file.

**Real AI video (free GPU).** Run `server/lumora_server.py` on a free GPU and paste its address in
Settings. See `server/colab_notebook.md`. The server uses the open LTX-Video model. The web app
only depends on a small HTTP contract (documented in `src/lib/generators/custom.js`), so you can
swap in Wan 2.1, CogVideoX or a Hugging Face Space by changing the server only.

Honest expectations: free GPUs give 3 to 8 second clips at roughly 512 px, and each takes minutes.

## Project map

```
src/lib/db.js            accounts, credits, clips; local cache + Supabase sync
src/lib/supabase.js      cloud-mode switch and client
src/lib/videos.js        video files: IndexedDB + Supabase Storage
src/lib/idb.js           IndexedDB wrapper
src/lib/jobs.js          starts, tracks and cancels generations
src/lib/generators/      mock.js (preview) and custom.js (your server), swapped in index.js
src/lib/render.js        procedural clip renderer + WebM recorder
src/lib/presets.js       styles, cameras, models, free-tier limits, example clips
src/pages/               one file per screen
server/                  the free-GPU generator server
supabase/schema.sql      phase 2: tables, security rules, storage bucket
supabase/phase3.sql      phase 3: locked credits, ledger, charging functions
supabase/functions/      phase 3: edge functions (generate, job-status, delete-account, ...)
supabase/tests/          backend tests (npm run test:backend)
```

## Phase 2: real accounts and cloud storage (Supabase, free tier)

Without keys Lumora runs entirely in the browser. With keys, the same app gets real email
accounts, a database, private video storage, password reset and sync across devices.

1. Create a free project at supabase.com.
2. In the dashboard open **SQL Editor**, paste the whole of `supabase/schema.sql`, and run it.
   This creates the tables, row level security (people can only touch their own rows), a signup
   trigger, and a private `videos` bucket.
3. **Project Settings > API**: copy the Project URL and the `anon public` key.
4. `cp .env.example .env` and paste both values in. Restart `npm run dev`.
5. **Authentication > URL Configuration**: set Site URL to where the app runs (for example
   `http://localhost:5173`) and add it to Redirect URLs, so confirmation and reset links come back.
6. When deploying (Vercel or Cloudflare Pages), add the same two values as environment variables.

What changes in cloud mode: sign up and log in use Supabase Auth (email confirmation and
"Forgot your password?" included), the demo account is hidden, clips and credits load on login
and save automatically, and generated videos are uploaded to your private folder in storage.
Settings shows the sync status. Your generator access token and uploaded start images stay in
the browser and are never synced.

## Phase 3: server-enforced credits and the free cloud GPU

Lumora is free. There are no plans, no payments and no billing code. Phase 3 only adds a daily credit
allowance so one person cannot use up the shared free GPU, and connects a free Google Colab GPU as the
"Lumora cloud" generator. It needs phase 2 to be set up first.

**What it does**

- Everyone gets 120 credits a day, clips up to 1 minute, 2 clips per run, every style and both models.
  Credits cannot be changed from the browser. The database refuses it. A person can still edit their
  name and generator settings, and claim the daily top-up (once a day, UTC).
- Clips on the **Lumora cloud** generator are charged by the server before anything reaches the GPU,
  refunded automatically if they fail or time out (after an hour), and keep rendering when the tab is
  closed. The GPU's address and token never reach the browser.
- Preview clips and clips on **My own server** stay unmetered, because they run on the person's side.
- "Delete account" is server side and removes the sign-in, clips and stored videos.

**Setup (all free tiers)**

1. **Database.** In the Supabase SQL Editor run `supabase/phase3.sql` (after `schema.sql`). Safe to re-run.
2. **Install and link the Supabase CLI**: `npm i -g supabase`, `supabase login`, then
   `supabase link --project-ref YOUR-PROJECT-REF` (the ref is in your project URL).
3. **Pick two long random secrets** (any password generator): one for `GENERATOR_TOKEN`, one for `REGISTER_KEY`.
4. **Set the function secrets**:
   ```bash
   supabase secrets set GENERATOR_TOKEN=... REGISTER_KEY=...
   ```
   `SUPABASE_URL` and the service key are provided to functions automatically.
5. **Deploy the functions**: `supabase functions deploy`
   (`supabase/config.toml` turns off the platform JWT check because each function verifies its caller itself;
   if your CLI ignores that, add `--no-verify-jwt`).
6. **Connect the GPU.** Open `server/colab_notebook.md`, run its cells with the same `GENERATOR_TOKEN` and
   `REGISTER_KEY`. The last cell registers the tunnel address with Lumora automatically, so a new Colab
   session needs no changes anywhere else.
7. **In the app:** Settings > Generator > **Lumora cloud**, then **Check that it is online**.

If strangers will use your copy, turn on email confirmation (and a captcha) in Supabase Auth settings so
people cannot farm daily credits with throwaway accounts.

**Free-tier realities.** Colab's free GPU disconnects after some hours and renders one clip at a time
(about 3 to 8 minutes per 5 seconds at 512 px, so a one minute clip can take an hour or more), so a batch queues. Long clips are rendered as a chain of 5 second pieces, each continuing from the last frame of the one before, so very long shots can drift in look. If Colab disconnects mid-clip, the credits are refunded after 3 hours. When it is offline the app says so and
disables Generate; nobody is charged. The app polls each running clip every 3 seconds, which counts toward
Supabase's free monthly function-call allowance.

## How it was tested

Run `npm run test:backend` to repeat the backend checks (no accounts needed, see `supabase/tests/README.md`).

- **Database rules** (`test:sql`, real Postgres via PGlite): both SQL files load and re-run; row level security;
  a signed-in user cannot raise credits, read the ledger or call the money functions; refunds
  happen once; limits and costs are enforced atomically; forged clip rows cannot be refunded.
- **Edge functions** (`test:functions`): the real function code against a stand-in Supabase on that same
  Postgres, a fake GPU: auth, validation, charging, failure and timeout refunds, an offline
  generator and account deletion.
- **The app in a browser** against the same stand-ins: sign-up, free preview clips, cloud-generator clips,
  resume after a reload, a second device, cheating attempts through the API, and
  account deletion. Local mode (no Supabase) was re-tested and is unchanged.

**Not verified, because no live accounts were available:** a real Supabase project, the Deno
runtime the functions run on (they were exercised under Node with a small import shim), and the Python
generator on a GPU. Treat your first deploy as the final test: run the SQL, deploy the functions, and render one clip.

## Known limits

- The limits (daily credits, clip length, batch size) live in two places that must be kept
  in step: `src/lib/presets.js` for the screens and `app_limits()` in `supabase/phase3.sql` for enforcement.
- Preview and own-server clips are not limited server side (they cost the owner nothing).
- The daily top-up resets at midnight UTC for everyone.
- Other devices signed in as a deleted account are signed out the next time their session refreshes.
- In local mode, passwords are hashed in the browser, which is fine for a demo only.
