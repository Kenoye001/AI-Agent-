import { Heart, Loader2, AlertTriangle, X } from 'lucide-react'
import ClipPlayer from './ClipPlayer'
import { cancelClip } from '../lib/jobs'
import { STYLES } from '../lib/presets'

// One tile in a grid. Handles every state a clip can be in.
export default function ClipCard({ clip, onOpen, onFavorite, onDismiss, showFavorite = false }) {
  const styleName = STYLES.find((s) => s.id === clip.style)?.label

  if (clip.status === 'processing') {
    return (
      <div className="overflow-hidden rounded-2xl border border-line bg-panel">
        <div className="shimmer relative grid place-items-center" style={{ aspectRatio: clip.aspect.replace(':', ' / ') }}>
          <div className="w-4/5 text-center">
            <Loader2 className="mx-auto mb-3 animate-spin text-lilac motion-reduce:animate-none" size={22} />
            <p className="text-sm font-semibold">{clip.stage}</p>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-ink/70" role="progressbar" aria-valuenow={Math.round(clip.progress * 100)} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full rounded-full bg-tally transition-[width] duration-300" style={{ width: `${Math.max(4, clip.progress * 100)}%` }} />
            </div>
            {clip.hosted ? (
              <p className="mt-4 text-[13px] text-mist">Rendering on the Lumora cloud. You can leave this page.</p>
            ) : (
              <button type="button" onClick={() => cancelClip(clip.id)} className="mt-4 text-[13px] font-medium text-mist underline underline-offset-4 hover:text-paper">{clip.cost > 0 ? 'Cancel and refund' : 'Cancel'}</button>
            )}
          </div>
        </div>
        <p className="line-clamp-2 p-3 text-sm text-mist">{clip.prompt}</p>
      </div>
    )
  }

  if (clip.status === 'failed' || clip.status === 'canceled') {
    return (
      <div className="overflow-hidden rounded-2xl border border-line bg-panel">
        <div className="grid place-items-center p-6 text-center" style={{ aspectRatio: clip.aspect.replace(':', ' / ') }}>
          <div>
            <AlertTriangle className="mx-auto mb-2 text-tally" size={22} />
            <p className="text-sm font-semibold">{clip.status === 'canceled' ? 'Canceled' : 'Generation failed'}</p>
            <p className="mt-1.5 text-[13px] leading-snug text-mist">{clip.error}</p>
            {onDismiss && (
              <button type="button" onClick={() => onDismiss(clip)} className="mt-3 inline-flex items-center gap-1 text-[13px] font-medium text-lilac underline underline-offset-4">
                <X size={13} /> Remove
              </button>
            )}
          </div>
        </div>
        <p className="line-clamp-1 p-3 text-sm text-mist">{clip.prompt}</p>
      </div>
    )
  }

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-line bg-panel">
      <button type="button" onClick={() => onOpen?.(clip)} className="block w-full text-left" aria-label={`Open clip: ${clip.prompt}`}>
        <ClipPlayer clip={clip} hoverPlay size={560} className="w-full" />
        <div className="p-3">
          <p className="line-clamp-2 text-sm text-paper">{clip.prompt}</p>
          <p className="mt-1.5 text-[13px] text-mist">{styleName} · {clip.duration}s · {clip.aspect}</p>
        </div>
      </button>
      {showFavorite && (
        <button
          type="button"
          onClick={() => onFavorite?.(clip)}
          aria-label={clip.favorite ? 'Remove from favorites' : 'Add to favorites'}
          aria-pressed={!!clip.favorite}
          className="absolute right-2.5 top-2.5 grid h-9 w-9 place-items-center rounded-full bg-black/55 backdrop-blur hover:bg-black/75"
        >
          <Heart size={17} className={clip.favorite ? 'fill-tally text-tally' : 'text-white'} />
        </button>
      )}
    </div>
  )
}
