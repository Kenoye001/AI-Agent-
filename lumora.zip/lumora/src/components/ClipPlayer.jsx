import { useEffect, useRef, useState } from 'react'
import { Pause, Play } from 'lucide-react'
import { drawFrame, dims } from '../lib/render'
import { loadVideo } from '../lib/videos'
import { useAccount } from '../lib/db'
import { loadImage } from '../lib/util'

// Plays a clip. Real videos (from a connected generator) use <video>; preview clips are drawn live on a canvas.
export default function ClipPlayer({ clip, controls = false, autoPlay = false, hoverPlay = false, size = 640, className = '' }) {
  const canvasRef = useRef(null)
  const videoRef = useRef(null)
  const [playing, setPlaying] = useState(autoPlay)
  const [hover, setHover] = useState(false)
  const [src, setSrc] = useState(null)
  const [missing, setMissing] = useState(false)
  const [t, setT] = useState(0.5)
  const tRef = useRef(0.5)
  const imgRef = useRef(null)
  const { userId } = useAccount()

  const active = playing || (hoverPlay && hover)
  const reduced = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches

  // Load the stored video file for real clips.
  useEffect(() => {
    if (!clip.hasVideo) return setSrc(null)
    let url
    let alive = true
    loadVideo(userId, clip.id)
      .then((b) => {
        if (!alive) return
        if (!b) return setMissing(true)
        url = URL.createObjectURL(b)
        setSrc(url)
      })
      .catch(() => alive && setMissing(true))
    return () => {
      alive = false
      if (url) URL.revokeObjectURL(url)
    }
  }, [clip.id, clip.hasVideo, userId])

  // Canvas preview loop.
  useEffect(() => {
    if (clip.hasVideo) return
    const canvas = canvasRef.current
    const [w, h] = dims(clip.aspect, size)
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')
    let raf
    let alive = true
    let start = performance.now() - tRef.current * clip.duration * 1000

    const go = async () => {
      if (clip.imageDataUrl && !imgRef.current) imgRef.current = await loadImage(clip.imageDataUrl).catch(() => null)
      if (!alive) return
      const frame = () => {
        if (!alive) return
        if (active && !reduced) {
          const el = performance.now() - start
          tRef.current = (el / (clip.duration * 1000)) % 1
          if (controls) setT(tRef.current)
        }
        drawFrame(ctx, w, h, tRef.current, clip, imgRef.current)
        if (active && !reduced) raf = requestAnimationFrame(frame)
      }
      frame()
    }
    go()
    return () => {
      alive = false
      cancelAnimationFrame(raf)
    }
  }, [clip, size, active, controls, reduced])

  const toggle = () => {
    if (clip.hasVideo) {
      const v = videoRef.current
      if (!v) return
      if (v.paused) v.play().catch(() => {})
      else v.pause()
    } else setPlaying((p) => !p)
  }

  const scrub = (e) => {
    const val = Number(e.target.value)
    if (clip.hasVideo && videoRef.current?.duration) videoRef.current.currentTime = val * videoRef.current.duration
    else {
      tRef.current = val
      setT(val)
      setPlaying(false)
    }
  }

  const ratio = clip.aspect.replace(':', ' / ')

  return (
    <div
      className={`relative overflow-hidden bg-black ${className}`}
      style={{ aspectRatio: ratio }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {clip.hasVideo ? (
        missing ? (
          <div className="absolute inset-0 grid place-items-center p-6 text-center text-sm text-mist">This clip's video file is no longer stored in this browser.</div>
        ) : (
          src && (
            <video
              ref={videoRef}
              src={src}
              className="h-full w-full object-cover"
              loop
              muted
              playsInline
              autoPlay={autoPlay}
              onPlay={() => setPlaying(true)}
              onPause={() => setPlaying(false)}
              onTimeUpdate={(e) => controls && e.target.duration && setT(e.target.currentTime / e.target.duration)}
              {...(hoverPlay ? { onMouseEnter: (e) => e.target.play().catch(() => {}), onMouseLeave: (e) => e.target.pause() } : {})}
            />
          )
        )
      ) : (
        <canvas ref={canvasRef} className="h-full w-full" />
      )}

      {controls && (
        <div className="absolute inset-x-0 bottom-0 flex items-center gap-3 bg-gradient-to-t from-black/70 to-transparent px-4 pb-3 pt-8">
          <button type="button" onClick={toggle} aria-label={playing ? 'Pause' : 'Play'} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-paper text-ink hover:bg-lilac">
            {playing ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="translate-x-px" />}
          </button>
          <input type="range" min="0" max="1" step="0.001" value={t} onChange={scrub} aria-label="Seek" className="h-1 w-full cursor-pointer" />
        </div>
      )}
    </div>
  )
}
