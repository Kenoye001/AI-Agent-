import { useEffect, useState, createContext, useContext, useCallback } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { Zap, Menu, X } from 'lucide-react'
import { Logo, Button, Toasts } from './ui'
import PasswordRecovery from './PasswordRecovery'
import { useAccount, logOut } from '../lib/db'

const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

const linkCls = ({ isActive }) => `rounded-full px-3.5 py-2 text-[15px] font-medium transition-colors ${isActive ? 'bg-raised text-paper' : 'text-mist hover:text-paper'}`

export default function Layout() {
  const { signedIn, data, user } = useAccount()
  const [open, setOpen] = useState(false)
  const [toasts, setToasts] = useState([])
  const loc = useLocation()
  const nav = useNavigate()

  const toast = useCallback((text, error = false) => {
    const id = Math.random()
    setToasts((t) => [...t, { id, text, error }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), error ? 6000 : 3200)
  }, [])

  useEffect(() => {
    setOpen(false)
    window.scrollTo(0, 0)
  }, [loc.pathname])

  const links = (
    <>
      <NavLink to="/explore" className={linkCls}>Explore</NavLink>
      <NavLink to="/credits" className={linkCls}>Credits</NavLink>
      {signedIn && (
        <>
          <NavLink to="/studio" className={linkCls}>Studio</NavLink>
          <NavLink to="/library" className={linkCls}>Library</NavLink>
          <NavLink to="/settings" className={linkCls}>Settings</NavLink>
        </>
      )}
    </>
  )

  return (
    <ToastCtx.Provider value={toast}>
      <div className="flex min-h-screen flex-col">
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[70] focus:rounded-full focus:bg-paper focus:px-4 focus:py-2 focus:text-ink">Skip to content</a>
        <header className="sticky top-0 z-40 border-b border-line/70 bg-ink/85 backdrop-blur">
          <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
            <Link to="/" aria-label="Lumora home"><Logo /></Link>
            <nav className="hidden items-center gap-1 md:flex" aria-label="Main">{links}</nav>
            <div className="ml-auto flex items-center gap-2">
              {signedIn ? (
                <>
                  <Link to="/credits" className="hidden items-center gap-1.5 rounded-full border border-line px-3.5 py-2 text-sm font-semibold hover:bg-raised sm:flex" title="Credits left today">
                    <Zap size={15} className="text-tally" /> {data.credits}
                  </Link>
                  <span className="hidden max-w-[10rem] truncate text-sm text-mist lg:block">{user.name}</span>
                  <Button variant="ghost" size="sm" className="hidden md:inline-flex" onClick={() => { logOut(); nav('/') }}>Log out</Button>
                </>
              ) : (
                <>
                  <Button as={Link} to="/login" variant="quiet" size="sm" className="hidden sm:inline-flex">Log in</Button>
                  <Button as={Link} to="/signup" size="sm">Start free</Button>
                </>
              )}
              <button type="button" className="grid h-10 w-10 place-items-center rounded-full text-paper hover:bg-raised md:hidden" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen((o) => !o)}>
                {open ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
          {open && (
            <nav className="flex flex-col gap-1 border-t border-line/70 px-4 py-3 md:hidden" aria-label="Mobile">
              {links}
              {signedIn ? (
                <button type="button" onClick={() => { logOut(); nav('/') }} className="rounded-full px-3.5 py-2 text-left text-[15px] font-medium text-mist">Log out ({data.credits} credits)</button>
              ) : (
                <NavLink to="/login" className={linkCls}>Log in</NavLink>
              )}
            </nav>
          )}
        </header>
        <main id="main" className="flex-1"><Outlet /></main>
        <footer className="border-t border-line/70">
          <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div>
              <Logo size={24} />
              <p className="mt-2 max-w-sm text-sm text-mist">A portfolio project. Preview clips are drawn in your browser; connect your own free generator in Settings for real video.</p>
            </div>
            <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-mist" aria-label="Footer">
              <Link className="hover:text-paper" to="/explore">Explore</Link>
              <Link className="hover:text-paper" to="/credits">Credits</Link>
              <Link className="hover:text-paper" to="/studio">Studio</Link>
              <Link className="hover:text-paper" to="/settings">Connect a generator</Link>
            </nav>
          </div>
        </footer>
      </div>
      <PasswordRecovery onDone={(t) => toast(t)} />
      <Toasts toasts={toasts} />
    </ToastCtx.Provider>
  )
}

export function RequireAuth({ children }) {
  const { signedIn } = useAccount()
  const loc = useLocation()
  if (!signedIn) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  return children
}

import { Navigate } from 'react-router-dom'
