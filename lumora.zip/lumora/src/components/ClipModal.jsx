import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Download, Heart, Shuffle, Trash2, Loader2 } from 'lucide-react'
import { Modal, Button } from './ui'
import ClipPlayer from './ClipPlayer'
import { useToast } from './Layout'
import { CAMERAS, STYLES, MODELS } from '../lib/presets'
import { loadVideo } from '../lib/videos'
import { recordClip } from '../lib/render'
import { downloadBlob, slugify, timeAgo } from '../lib/util'
import { removeClip, toggleFavorite, useAccount } from '../lib/db'

export default function ClipModal({ clip, onClose, sample = false }) {
  const nav = useNavigate()
  const toast = useToast()
  const { email, signedIn, data, userId } = useAccount()
  const [busy, setBusy] = useState(0)
  const [recording, setRecording] = useState(false)

  if (!clip) return null
  const live = sample ? clip : data?.clips.find((c) => c.id === clip.id) || clip

  const download = async () => {
    try {
      if (live.hasVideo) {
        const blob = await loadVideo(userId, live.id)
        if (!blob) throw new Error('The video file is no longer stored in this browser.')
        downloadBlob(blob, `${slugify(live.prompt)}.${blob.type.includes('mp4') ? 'mp4' : 'webm'}`)
        return
      }
      setRecording(true)
      setBusy(0)
      const blob = await recordClip(live, { size: 1080, onProgress: setBusy })
      downloadBlob(blob, `${slugify(live.prompt)}.webm`)
      toast('Download started')
    } catch (e) {
      toast(e.message, true)
    } finally {
      setRecording(false)
    }
  }

  const remix = () => {
    onClose()
    nav('/studio', { state: { remix: { prompt: live.prompt, style: live.style, camera: live.camera, aspect: live.aspect, duration: live.duration, negative: live.negative || '', model: live.model || 'flow' } } })
  }

  const rows = [
    ['Style', STYLES.find((s) => s.id === live.style)?.label],
    ['Camera', CAMERAS.find((c) => c.id === live.camera)?.label],
    ['Length', `${live.duration} seconds`],
    ['Shape', live.aspect],
    ...(live.model ? [['Model', MODELS.find((m) => m.id === live.model)?.label]] : []),
    ...(live.createdAt && !sample ? [['Made', timeAgo(live.createdAt)]] : []),
  ]

  return (
    <Modal open onClose={onClose} title="Clip" wide>
      <div className="grid gap-6 md:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div className="mx-auto w-full max-w-full self-start overflow-hidden rounded-2xl" style={{ maxWidth: live.aspect === '9:16' ? '22rem' : '100%' }}>
          <ClipPlayer clip={live} controls autoPlay size={960} className="w-full" />
        </div>
        <div>
          <p className="text-[17px] leading-relaxed">{live.prompt}</p>
          <dl className="mt-5 grid grid-cols-[auto_1fr] gap-x-5 gap-y-2 text-sm">
            {rows.map(([k, v]) => (
              <div key={k} className="contents">
                <dt className="text-mist">{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
          {!live.real && !live.hasVideo && (
            <p className="mt-5 rounded-xl border border-line bg-panel p-3 text-[13px] leading-snug text-mist">
              This is a preview clip drawn in your browser. Connect a generator in Settings to get real AI video.
            </p>
          )}
          <div className="mt-6 flex flex-wrap gap-2">
            <Button onClick={download} disabled={recording}>
              {recording ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
              {recording ? `Recording ${Math.round(busy * 100)}%` : 'Download'}
            </Button>
            <Button variant="ghost" onClick={remix}><Shuffle size={16} /> Remix</Button>
            {signedIn && !sample && (
              <>
                <Button variant="ghost" aria-pressed={!!live.favorite} onClick={() => toggleFavorite(email, live.id)}>
                  <Heart size={16} className={live.favorite ? 'fill-tally text-tally' : ''} /> {live.favorite ? 'Favorited' : 'Favorite'}
                </Button>
                <Button variant="danger" onClick={() => { removeClip(email, live.id); toast('Clip deleted'); onClose() }}><Trash2 size={16} /> Delete</Button>
              </>
            )}
          </div>
        </div>
      </div>
    </Modal>
  )
}
