import { useState } from 'react'
import { Modal, Button, ErrorNote, Field, inputCls } from './ui'
import { dismissRecovery, updatePassword, useRecovery } from '../lib/db'

// Shown after someone opens the reset link from their email.
export default function PasswordRecovery({ onDone }) {
  const open = useRecovery()
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    setBusy(true)
    try {
      await updatePassword(pw)
      setPw('')
      onDone?.('Password updated')
    } catch (e2) {
      setErr(e2.message)
    }
    setBusy(false)
  }

  return (
    <Modal open={open} onClose={dismissRecovery} title="Set a new password">
      <form onSubmit={submit} className="space-y-4">
        <Field label="New password" hint="At least 8 characters.">
          <input className={inputCls} type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" autoFocus />
        </Field>
        <ErrorNote>{err}</ErrorNote>
        <Button type="submit" variant="accent" className="w-full" disabled={busy}>Save password</Button>
      </form>
    </Modal>
  )
}
