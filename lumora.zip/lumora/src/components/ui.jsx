import { useEffect } from 'react'
import { X } from 'lucide-react'

export function Logo({ size = 28 }) {
  return (
    <span className="inline-flex items-center gap-2.5 font-display text-xl font-bold tracking-tight">
      <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="#2f2859" />
        <path d="M9 8v16h14" fill="none" stroke="#c9b6ff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="21" cy="11" r="3" fill="#ff5a7a" />
      </svg>
      Lumora
    </span>
  )
}

const base = 'inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50'
const sizes = { md: 'h-11 px-5 text-[15px]', sm: 'h-9 px-4 text-sm', lg: 'h-13 px-7 text-base' }
const variants = {
  primary: 'bg-paper text-ink hover:bg-lilac',
  accent: 'bg-tally text-white hover:bg-[#ff7d97]',
  ghost: 'border border-line text-paper hover:bg-raised',
  quiet: 'text-mist hover:bg-raised hover:text-paper',
  danger: 'border border-tally/50 text-tally hover:bg-tally/10',
}
export function Button({ variant = 'primary', size = 'md', className = '', as: As = 'button', ...p }) {
  return <As className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...(As === 'button' ? { type: 'button' } : {})} {...p} />
}

export function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-paper">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[13px] text-mist">{hint}</span>}
    </label>
  )
}

export const inputCls = 'h-11 w-full rounded-xl border border-line bg-ink px-3.5 text-[15px] text-paper placeholder:text-mist/60 focus:border-lilac focus:outline-none'

export function Segmented({ value, onChange, options, label, className = '' }) {
  return (
    <div role="radiogroup" aria-label={label} className={`flex flex-wrap gap-1.5 ${className}`}>
      {options.map((o) => {
        const id = o.id ?? o
        const on = value === id
        return (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={on}
            disabled={o.disabled}
            title={o.title}
            onClick={() => onChange(id)}
            className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors disabled:opacity-40 ${on ? 'border-paper bg-paper text-ink' : 'border-line text-mist hover:border-mist hover:text-paper'}`}
          >
            {o.label ?? o}
          </button>
        )
      })}
    </div>
  )
}

export function Modal({ open, onClose, title, children, wide }) {
  useEffect(() => {
    if (!open) return
    const k = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', k)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', k)
      document.body.style.overflow = ''
    }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`max-h-[92vh] w-full overflow-auto rounded-t-3xl border border-line bg-deep p-5 sm:rounded-3xl sm:p-7 ${wide ? 'max-w-4xl' : 'max-w-md'}`}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 className="font-display text-2xl font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-mist hover:bg-raised hover:text-paper">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Toasts({ toasts }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-5 z-[60] flex flex-col items-center gap-2 px-4" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`pointer-events-auto rounded-full border px-5 py-2.5 text-sm font-medium shadow-xl ${t.error ? 'border-tally/50 bg-[#3a1626] text-[#ffd5dd]' : 'border-line bg-raised text-paper'}`}>
          {t.text}
        </div>
      ))}
    </div>
  )
}

export function ErrorNote({ children }) {
  if (!children) return null
  return (
    <p role="alert" className="rounded-xl border border-tally/40 bg-tally/10 px-3.5 py-2.5 text-sm text-[#ffd5dd]">
      {children}
    </p>
  )
}
