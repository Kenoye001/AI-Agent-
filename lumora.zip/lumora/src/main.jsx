import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import './index.css'
import App from './App'
import { initCloud, recoverInterrupted, refillIfNeeded } from './lib/db'

// Clips that were mid-render when the tab closed cannot finish: fail and refund them.
recoverInterrupted()
refillIfNeeded()
initCloud()

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <HashRouter>
      <App />
    </HashRouter>
  </StrictMode>,
)
