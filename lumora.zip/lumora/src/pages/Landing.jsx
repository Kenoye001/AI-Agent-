import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, Clapperboard, ImagePlus, Download, Camera, Layers, Plug } from 'lucide-react'
import { Button } from '../components/ui'
import ClipPlayer from '../components/ClipPlayer'
import { SHOWCASE, CAMERAS, PLANS, PROMPT_IDEAS } from '../lib/presets'
import { useAccount } from '../lib/db'

const asClip = (s) => ({ ...s, id: s.id, duration: 5, status: 'done', model: 'flow' })
const HERO = [SHOWCASE[0], SHOWCASE[1], SHOWCASE[4], SHOWCASE[3]].map(asClip)

function useCycle(n, ms) {
  const [i, setI] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setI((x) => (x + 1) % n), ms)
    return () => clearInterval(id)
  }, [n, ms])
  return [i, setI]
}

export default function Landing() {
  const { signedIn } = useAccount()
  const nav = useNavigate()
  const [i, setI] = useCycle(HERO.length, 7000)
  const [text, setText] = useState('')
  const cur = HERO[i]
  const camLabel = CAMERAS.find((c) => c.id === cur.camera)?.label

  const go = (e) => {
    e.preventDefault()
    nav(signedIn ? '/studio' : '/signup', { state: text.trim() ? { remix: { prompt: text.trim() } } : undefined })
  }

  return (
    <>
      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-14 lg:pt-20">
        <div>
          <h1 className="text-[2.6rem] font-extrabold leading-[1.02] sm:text-6xl lg:text-7xl">
            Direct the camera, not just the prompt.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-mist">
            Describe a shot, pick a lens move like a dolly-in or a crane up, and get a short cinematic clip. Start from words or from a still image.
          </p>
          <form onSubmit={go} className="mt-8 flex max-w-xl flex-col gap-3 rounded-3xl border border-line bg-panel p-3 sm:flex-row sm:items-center sm:rounded-full sm:p-2 sm:pl-5">
            <label htmlFor="hero-prompt" className="sr-only">Describe your shot</label>
            <input
              id="hero-prompt"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={PROMPT_IDEAS[i % PROMPT_IDEAS.length]}
              className="h-11 min-w-0 flex-1 bg-transparent px-2 text-[15px] placeholder:text-mist/60 focus:outline-none sm:px-0"
            />
            <Button type="submit" variant="accent" className="shrink-0">Generate <ArrowRight size={16} /></Button>
          </form>
          <p className="mt-3 text-sm text-mist">Free forever: 120 credits a day, no card needed.</p>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-3xl border border-line shadow-[0_30px_80px_-30px_rgba(255,90,122,.35)]">
            <ClipPlayer key={cur.id} clip={cur} autoPlay size={900} className="w-full" />
          </div>
          <div className="mt-4 flex items-start justify-between gap-4">
            <p className="text-sm leading-snug text-mist"><span className="text-paper">{camLabel}.</span> {cur.prompt}</p>
            <div className="flex shrink-0 gap-1.5 pt-1.5" role="tablist" aria-label="Sample clips">
              {HERO.map((h, k) => (
                <button key={h.id} role="tab" aria-selected={k === i} aria-label={`Sample ${k + 1}`} onClick={() => setI(k)} className={`h-2 rounded-full transition-all ${k === i ? 'w-6 bg-tally' : 'w-2 bg-line hover:bg-mist'}`} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="overflow-hidden border-y border-line/70 py-6" aria-label="Sample clips">
        <div className="marquee flex w-max gap-4">
          {[...SHOWCASE, ...SHOWCASE].map((s, k) => (
            <div key={k} className="h-36 shrink-0 overflow-hidden rounded-xl sm:h-44" style={{ aspectRatio: s.aspect.replace(':', ' / ') }} aria-hidden={k >= SHOWCASE.length}>
              <ClipPlayer clip={asClip(s)} size={320} className="h-full w-full" />
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <h2 className="max-w-2xl text-4xl font-bold leading-tight sm:text-5xl">Everything you need to go from idea to clip.</h2>
        <div className="mt-12 grid gap-x-10 gap-y-12 md:grid-cols-2 lg:grid-cols-3">
          {[
            [Camera, 'Thirteen camera moves', 'Dolly, crane, orbit, whip pan, crash zoom, FPV and more. Pick the move and the model follows it.'],
            [ImagePlus, 'Bring your own still', 'Upload a photo and animate it with a camera move, a style grade and a short description.'],
            [Layers, 'Eight looks', 'From film noir to claymation. Each look sets color, grain, framing and mood in one click.'],
            [Clapperboard, 'Batch and remix', 'Render up to four takes at once, then remix any clip from the library with the same settings.'],
            [Download, 'Download anything', 'Every clip exports as a video file you can drop straight into your editor or post.'],
            [Plug, 'Plug in your own model', 'Point Lumora at a free generator running on Colab, Hugging Face or your own GPU for real AI video.'],
          ].map(([Icon, title, body]) => (
            <div key={title}>
              <Icon size={24} className="text-lilac" />
              <h3 className="mt-4 text-xl font-bold">{title}</h3>
              <p className="mt-2 max-w-sm leading-relaxed text-mist">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-line/70 bg-deep">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <h2 className="text-4xl font-bold sm:text-5xl">How a clip gets made</h2>
          <ol className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              ['Describe the shot', 'Write one sentence, or upload a still image to start from.'],
              ['Choose the look and the move', 'Pick a style, a camera move, a shape and a length. The credit cost updates as you go.'],
              ['Generate, then refine', 'Watch the queue, review the take, and remix it until it feels right.'],
            ].map(([t, b], k) => (
              <li key={t} className="rounded-3xl border border-line bg-panel p-7">
                <span className="font-display text-5xl font-extrabold text-tally">{k + 1}</span>
                <h3 className="mt-4 text-xl font-bold">{t}</h3>
                <p className="mt-2 leading-relaxed text-mist">{b}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h2 className="text-4xl font-bold sm:text-5xl">Free, with no catch.</h2>
          <Button as={Link} to="/credits" variant="ghost">How credits work</Button>
        </div>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-mist">
          Every account gets {PLANS.free.daily} credits a day, clips up to {PLANS.free.maxDuration} seconds, and every style, camera move and model. There are no plans and no payments. Credits just keep the shared free GPU fair for everyone.
        </p>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6">
        <div className="rounded-[2rem] bg-gradient-to-br from-raised to-panel px-6 py-16 text-center sm:px-12">
          <h2 className="mx-auto max-w-2xl text-4xl font-bold leading-tight sm:text-5xl">Your first clip is a sentence away.</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button as={Link} to={signedIn ? '/studio' : '/signup'} variant="accent" size="lg">{signedIn ? 'Open the studio' : 'Create a free account'}</Button>
            <Button as={Link} to="/explore" variant="ghost" size="lg">Browse examples</Button>
          </div>
        </div>
      </section>
    </>
  )
}
