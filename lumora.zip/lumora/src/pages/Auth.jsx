import { useState } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { Button, ErrorNote, Field, Logo, inputCls } from '../components/ui'
import { cloudEnabled, demoLogin, logIn, requestPasswordReset, signUp, useAccount } from '../lib/db'

export default function Auth({ mode }) {
  const signup = mode === 'signup'
  const { signedIn } = useAccount()
  const nav = useNavigate()
  const loc = useLocation()
  const [f, setF] = useState({ name: '', email: '', password: '' })
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')
  const [busy, setBusy] = useState(false)

  const remixState = loc.state?.remix ? { remix: loc.state.remix } : undefined
  if (signedIn) return <Navigate to={loc.state?.from || '/studio'} replace state={remixState} />

  const set = (k) => (e) => setF((v) => ({ ...v, [k]: e.target.value }))

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    setInfo('')
    setBusy(true)
    try {
      const res = await (signup ? signUp(f) : logIn(f))
      if (res?.needsConfirm) {
        setInfo(`We sent a confirmation link to ${f.email.trim()}. Open it, then come back and log in.`)
        setBusy(false)
        return
      }
      nav(loc.state?.from || '/studio', { replace: true, state: remixState })
    } catch (e2) {
      setErr(e2.message)
      setBusy(false)
    }
  }

  const forgot = async () => {
    setErr('')
    setInfo('')
    try {
      await requestPasswordReset(f.email)
      setInfo(`If ${f.email.trim()} has an account, a reset link is on its way.`)
    } catch (e) {
      setErr(e.message)
    }
  }

  return (
    <div className="mx-auto grid max-w-md px-4 py-14 sm:py-20">
      <div className="mb-8"><Logo /></div>
      <h1 className="text-4xl font-extrabold">{signup ? 'Create your account' : 'Welcome back'}</h1>
      <p className="mt-2 text-mist">{signup ? 'You get 30 free credits every day.' : 'Log in to pick up where you left off.'}</p>

      <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
        {signup && (
          <Field label="Name">
            <input className={inputCls} value={f.name} onChange={set('name')} autoComplete="name" required />
          </Field>
        )}
        <Field label="Email">
          <input className={inputCls} type="email" value={f.email} onChange={set('email')} autoComplete="email" required />
        </Field>
        <Field label="Password" hint={signup ? 'At least 8 characters.' : undefined}>
          <input className={inputCls} type="password" value={f.password} onChange={set('password')} autoComplete={signup ? 'new-password' : 'current-password'} required />
        </Field>
        {!signup && cloudEnabled && (
          <button type="button" onClick={forgot} className="-mt-1 text-sm text-lilac underline underline-offset-4">Forgot your password?</button>
        )}
        <ErrorNote>{err}</ErrorNote>
        {info && (
          <p role="status" className="flex items-start gap-2.5 rounded-xl border border-ok/40 bg-ok/10 px-3.5 py-2.5 text-sm text-ok">
            <MailCheck size={18} className="mt-0.5 shrink-0" /> {info}
          </p>
        )}
        <Button type="submit" variant="accent" className="w-full" disabled={busy}>{busy ? 'One moment' : signup ? 'Create account' : 'Log in'}</Button>
      </form>

      {!cloudEnabled && (
        <>
          <div className="my-6 flex items-center gap-3 text-sm text-mist"><span className="h-px flex-1 bg-line" /> or <span className="h-px flex-1 bg-line" /></div>
          <Button variant="ghost" className="w-full" onClick={() => { demoLogin(); nav(loc.state?.from || '/studio', { replace: true }) }}>Try the demo account</Button>
        </>
      )}

      <p className="mt-8 text-center text-mist">
        {signup ? 'Already have an account? ' : 'New to Lumora? '}
        <Link to={signup ? '/login' : '/signup'} state={loc.state} className="text-lilac underline underline-offset-4">{signup ? 'Log in' : 'Create an account'}</Link>
      </p>
      <p className="mt-6 text-center text-[13px] text-mist/80">
        {cloudEnabled ? 'Your account and clips are saved to the cloud, so they follow you to any device.' : 'Accounts are stored in this browser only. This is a demo, so do not reuse a real password.'}
      </p>
    </div>
  )
}
