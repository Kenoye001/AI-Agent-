import { useMemo, useState } from 'react'
import { SHOWCASE, SHOWCASE_TAGS } from '../lib/presets'
import { Segmented } from '../components/ui'
import ClipCard from '../components/ClipCard'
import ClipModal from '../components/ClipModal'

const clips = SHOWCASE.map((s) => ({ ...s, duration: 5, status: 'done', model: 'flow' }))

export default function Explore() {
  const [tag, setTag] = useState('All')
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(null)

  const shown = useMemo(
    () => clips.filter((c) => (tag === 'All' || c.tag === tag) && c.prompt.toLowerCase().includes(q.trim().toLowerCase())),
    [tag, q],
  )

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Explore</h1>
      <p className="mt-3 max-w-xl text-mist">Open any example to see its settings, then remix it in the studio.</p>

      <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <Segmented label="Filter by category" value={tag} onChange={setTag} options={SHOWCASE_TAGS} />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search prompts"
          aria-label="Search prompts"
          className="h-11 w-full rounded-full border border-line bg-ink px-5 text-[15px] placeholder:text-mist/60 focus:border-lilac focus:outline-none sm:w-72"
        />
      </div>

      {shown.length ? (
        <div className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3">
          {shown.map((c) => (
            <div key={c.id} className="mb-4 break-inside-avoid">
              <ClipCard clip={c} onOpen={setOpen} />
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-16 text-center text-mist">No examples match that search. Clear the search or pick another category.</p>
      )}

      <ClipModal clip={open} sample onClose={() => setOpen(null)} />
    </div>
  )
}
