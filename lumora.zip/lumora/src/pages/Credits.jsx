import { Link } from 'react-router-dom'
import { Button } from '../components/ui'
import { PLANS, MODELS } from '../lib/presets'
import { useAccount } from '../lib/db'

const FAQ = [
  ['Is anything paid?', 'No. Lumora has no plans, no checkout and no card forms. Everything runs on free tools.'],
  ['Why are there credits at all?', 'The cloud generator runs on a free shared GPU. Credits stop one person from using it all up. Preview mode and your own generator never use credits.'],
  ['When do credits refill?', 'Once a day, at midnight UTC, back up to your daily amount. Unused credits do not stack.'],
  ['What if a clip fails?', 'The credits for that clip go back to you automatically. Clips stuck in the queue for over an hour are refunded too.'],
  ['Can I get more?', 'Run your own generator (see Settings). It has no limits besides your own GPU time.'],
]

export default function Credits() {
  const { signedIn, data } = useAccount()
  const p = PLANS.free
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Free, every day</h1>
      <p className="mt-4 text-lg leading-relaxed text-mist">
        You get {p.daily} credits each day, clips up to {p.maxDuration} seconds, and up to {p.maxBatch} clips per run at {p.resolution}.
      </p>
      {signedIn && <p className="mt-3 font-semibold">You have {data.credits} credits left today.</p>}
      <ul className="mt-8 grid gap-3 sm:grid-cols-2">
        {MODELS.map((m) => (
          <li key={m.id} className="rounded-2xl border border-line bg-panel p-5">
            <h2 className="text-lg font-bold">{m.label}</h2>
            <p className="mt-1 text-mist">{m.blurb}</p>
          </li>
        ))}
      </ul>
      <dl className="mt-10 space-y-6">
        {FAQ.map(([q, a]) => (
          <div key={q}><dt className="font-bold">{q}</dt><dd className="mt-1 leading-relaxed text-mist">{a}</dd></div>
        ))}
      </dl>
      <Button as={Link} to={signedIn ? '/studio' : '/signup'} className="mt-10">{signedIn ? 'Open the studio' : 'Start free'}</Button>
    </div>
  )
}
