import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button, Segmented } from '../components/ui'
import ClipCard from '../components/ClipCard'
import ClipModal from '../components/ClipModal'
import { removeClip, toggleFavorite, useAccount } from '../lib/db'

export default function Library() {
  const { email, data } = useAccount()
  const [filter, setFilter] = useState('all')
  const [sort, setSort] = useState('new')
  const [open, setOpen] = useState(null)

  const clips = useMemo(() => {
    let c = data.clips.filter((x) => (filter === 'fav' ? x.favorite : filter === 'img' ? x.mode === 'image' : true))
    c = [...c].sort((a, b) => (sort === 'new' ? b.createdAt - a.createdAt : a.createdAt - b.createdAt))
    return c
  }, [data.clips, filter, sort])

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-extrabold sm:text-5xl">Library</h1>
          <p className="mt-2 text-mist">{data.clips.length} clip{data.clips.length === 1 ? '' : 's'} saved in this browser.</p>
        </div>
        <Button as={Link} to="/studio" variant="accent">New clip</Button>
      </div>

      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        <Segmented label="Filter" value={filter} onChange={setFilter} options={[{ id: 'all', label: 'All' }, { id: 'fav', label: 'Favorites' }, { id: 'img', label: 'From images' }]} />
        <Segmented label="Sort" value={sort} onChange={setSort} options={[{ id: 'new', label: 'Newest first' }, { id: 'old', label: 'Oldest first' }]} />
      </div>

      {clips.length ? (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {clips.map((c) => (
            <ClipCard key={c.id} clip={c} showFavorite onOpen={setOpen} onFavorite={(x) => toggleFavorite(email, x.id)} onDismiss={(x) => removeClip(email, x.id)} />
          ))}
        </div>
      ) : (
        <div className="mt-12 rounded-3xl border border-dashed border-line p-12 text-center">
          <p className="text-lg font-semibold">{data.clips.length ? 'Nothing matches this filter' : 'Your library is empty'}</p>
          <p className="mx-auto mt-1 max-w-sm text-mist">{data.clips.length ? 'Switch the filter to All to see everything.' : 'Generate your first clip in the studio and it will be saved here.'}</p>
        </div>
      )}
      <ClipModal clip={open} onClose={() => setOpen(null)} />
    </div>
  )
}
