import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Zap, Dices, ImagePlus, Sparkles, Type, X } from 'lucide-react'
import { Button, ErrorNote, Field, Segmented, inputCls } from '../components/ui'
import ClipCard from '../components/ClipCard'
import ClipModal from '../components/ClipModal'
import { useToast } from '../components/Layout'
import { ASPECTS, CAMERAS, DURATIONS, MODELS, PLANS, PROMPT_IDEAS, STYLES, creditCost } from '../lib/presets'
import { removeClip, useAccount } from '../lib/db'
import { chargesCredits, isHosted, startGeneration } from '../lib/jobs'
import { callFn } from '../lib/supabase'
import { isRealProvider } from '../lib/generators'
import { fileToResizedDataUrl, randomSeed } from '../lib/util'

const DEFAULTS = { mode: 'text', prompt: '', negative: '', style: 'cinematic', camera: 'dolly_in', aspect: '16:9', duration: 5, model: 'flow', count: 1, seed: '', imageDataUrl: null }

export default function Studio() {
  const { email, data, plan } = useAccount()
  const toast = useToast()
  const loc = useLocation()
  const [f, setF] = useState(() => ({ ...DEFAULTS, ...(loc.state?.remix || {}) }))
  const [err, setErr] = useState('')
  const [open, setOpen] = useState(null)
  const fileRef = useRef(null)
  const [drag, setDrag] = useState(false)

  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }))

  // Respond to a remix sent while already on this page.
  useEffect(() => {
    if (loc.state?.remix) setF((x) => ({ ...x, ...loc.state.remix }))
  }, [loc.key])

  // Keep choices inside what the current plan allows.
  useEffect(() => {
    setF((x) => ({
      ...x,
      duration: Math.min(x.duration, plan.maxDuration),
      count: Math.min(x.count, plan.maxBatch),
    }))
  }, [plan])

  const charged = chargesCredits(data.settings)
  const hosted = isHosted(data.settings)
  const cost = charged ? creditCost(f.model, f.duration) * f.count : 0
  const short = charged && cost > data.credits
  const busyCount = data.clips.filter((c) => c.status === 'processing').length
  const recent = useMemo(() => data.clips.slice(0, 12), [data.clips])
  const real = isRealProvider(data.settings)
  const [busy, setBusy] = useState(false)
  const [gen, setGen] = useState('checking') // cloud generator: checking | online | offline | unconfigured

  // Tell people whether the cloud generator is up before they spend credits on it.
  useEffect(() => {
    if (!hosted) return
    let alive = true
    const check = () =>
      callFn('generator-status')
        .then((r) => alive && setGen(!r.configured ? 'unconfigured' : r.online ? 'online' : 'offline'))
        .catch(() => alive && setGen('offline'))
    check()
    const id = setInterval(check, 30000)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [hosted])

  const pickFile = async (file) => {
    if (!file) return
    setErr('')
    try {
      set('imageDataUrl')(await fileToResizedDataUrl(file))
    } catch (e) {
      setErr(e.message)
    }
  }

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    setBusy(true)
    try {
      await startGeneration(email, { ...f, seed: f.seed === '' ? undefined : Number(f.seed) })
      toast(f.count > 1 ? `Started ${f.count} clips` : 'Started your clip')
    } catch (e2) {
      setErr(e2.message)
    }
    setBusy(false)
  }

  return (
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)] xl:grid-cols-[minmax(0,28rem)_minmax(0,1fr)]">
      <form onSubmit={submit} className="space-y-6 lg:sticky lg:top-24 lg:max-h-[calc(100vh-7rem)] lg:self-start lg:overflow-y-auto lg:pr-2">
        <Segmented
          label="Start from"
          value={f.mode}
          onChange={set('mode')}
          options={[{ id: 'text', label: 'Text to video' }, { id: 'image', label: 'Image to video' }]}
        />

        {f.mode === 'image' && (
          <div>
            <span className="mb-1.5 block text-sm font-semibold">Start image</span>
            {f.imageDataUrl ? (
              <div className="relative overflow-hidden rounded-2xl border border-line">
                <img src={f.imageDataUrl} alt="Your start image" className="max-h-56 w-full object-cover" />
                <button type="button" onClick={() => set('imageDataUrl')(null)} aria-label="Remove image" className="absolute right-2 top-2 grid h-9 w-9 place-items-center rounded-full bg-black/65 hover:bg-black"><X size={17} /></button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
                onDragLeave={() => setDrag(false)}
                onDrop={(e) => { e.preventDefault(); setDrag(false); pickFile(e.dataTransfer.files[0]) }}
                className={`grid h-40 w-full place-items-center rounded-2xl border-2 border-dashed text-center transition-colors ${drag ? 'border-lilac bg-raised' : 'border-line hover:border-mist'}`}
              >
                <span className="text-mist"><ImagePlus className="mx-auto mb-2" /> Drop an image here, or click to choose one</span>
              </button>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="sr-only" onChange={(e) => { pickFile(e.target.files[0]); e.target.value = '' }} />
          </div>
        )}

        <Field label={f.mode === 'image' ? 'What should move? (optional)' : 'Describe the shot'}>
          <textarea
            value={f.prompt}
            onChange={(e) => set('prompt')(e.target.value)}
            rows={4}
            maxLength={500}
            placeholder={PROMPT_IDEAS[0]}
            className="w-full resize-none rounded-xl border border-line bg-ink p-3.5 text-[15px] leading-relaxed placeholder:text-mist/60 focus:border-lilac focus:outline-none"
          />
        </Field>
        <button type="button" onClick={() => set('prompt')(PROMPT_IDEAS[Math.floor(Math.random() * PROMPT_IDEAS.length)])} className="-mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-lilac hover:underline">
          <Sparkles size={14} /> Suggest an idea
        </button>

        <div>
          <span className="mb-2 block text-sm font-semibold">Look</span>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4" role="radiogroup" aria-label="Look">
            {STYLES.map((s) => (
              <button
                key={s.id}
                type="button"
                role="radio"
                aria-checked={f.style === s.id}
                onClick={() => set('style')(s.id)}
                title={s.hint}
                className={`overflow-hidden rounded-xl border text-left transition-colors ${f.style === s.id ? 'border-paper' : 'border-line hover:border-mist'}`}
              >
                <span className="block h-10" style={{ background: `linear-gradient(135deg, ${s.sky[0]}, ${s.sky[1]} 55%, ${s.sky[2]})` }} />
                <span className="block px-2 py-1.5 text-[13px] font-medium">{s.label}</span>
              </button>
            ))}
          </div>
        </div>

        <Field label="Camera move">
          <select value={f.camera} onChange={(e) => set('camera')(e.target.value)} className={inputCls}>
            {CAMERAS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </Field>

        <div>
          <span className="mb-2 block text-sm font-semibold">Shape</span>
          <Segmented label="Shape" value={f.aspect} onChange={set('aspect')} options={ASPECTS.map((a) => ({ id: a.id, label: `${a.id} ${a.label}` }))} />
        </div>

        <div>
          <span className="mb-2 block text-sm font-semibold">Length</span>
          <Segmented
            label="Length"
            value={f.duration}
            onChange={set('duration')}
            options={DURATIONS.filter((d) => d <= plan.maxDuration).map((d) => ({ id: d, label: `${d}s`, disabled: d > plan.maxDuration, title: undefined }))}
          />
        </div>

        <div>
          <span className="mb-2 block text-sm font-semibold">Model</span>
          <Segmented
            label="Model"
            value={f.model}
            onChange={set('model')}
            options={MODELS.map((m) => ({ id: m.id, label: m.label, title: m.blurb }))}
          />
          <p className="mt-1.5 text-[13px] text-mist">{MODELS.find((m) => m.id === f.model).blurb}</p>
        </div>

        <div>
          <span className="mb-2 block text-sm font-semibold">Clips per run</span>
          <Segmented
            label="Clips per run"
            value={f.count}
            onChange={set('count')}
            options={[1, 2, 3, 4].map((n) => ({ id: n, label: String(n), disabled: n > plan.maxBatch }))}
          />
        </div>

        <details className="rounded-xl border border-line px-4 py-3">
          <summary className="cursor-pointer text-sm font-semibold">Advanced</summary>
          <div className="mt-4 space-y-4">
            <Field label="Avoid" hint="Things you do not want in the shot.">
              <input className={inputCls} value={f.negative} onChange={(e) => set('negative')(e.target.value)} placeholder="text, watermark, blurry" />
            </Field>
            <Field label="Seed" hint="Reuse a number to get the same take again. Leave empty for random.">
              <div className="flex gap-2">
                <input className={inputCls} inputMode="numeric" value={f.seed} onChange={(e) => set('seed')(e.target.value.replace(/\D/g, '').slice(0, 9))} placeholder="Random" />
                <Button variant="ghost" className="shrink-0 px-3" aria-label="Roll a random seed" onClick={() => set('seed')(String(randomSeed()))}><Dices size={18} /></Button>
              </div>
            </Field>
          </div>
        </details>

        <ErrorNote>{err}</ErrorNote>

        <div className="sticky bottom-0 -mx-1 bg-ink/95 px-1 pb-1 pt-3 backdrop-blur">
          <Button type="submit" variant="accent" size="lg" className="w-full" disabled={short || busy || (hosted && (gen === 'offline' || gen === 'unconfigured'))}>
            <Sparkles size={18} /> {busy ? 'Starting' : `Generate${f.count > 1 ? ` ${f.count} clips` : ''}`}
            {charged ? <> · {cost} <Zap size={16} /></> : ' · free'}
          </Button>
          <p className="mt-2 text-center text-[13px] text-mist">
            {hosted && gen === 'offline' ? (
              'The Lumora cloud generator is offline right now. Try again later, or switch to Preview in Settings.'
            ) : hosted && gen === 'unconfigured' ? (
              'The cloud generator has not been connected yet. See the README, phase 3.'
            ) : !charged ? (
              'Runs on your own generator, so it costs no credits.'
            ) : short ? (
              <>You have {data.credits} credits. <Link to="/credits" className="text-lilac underline">How credits work</Link></>
            ) : (
              `You have ${data.credits} credits left today.`
            )}
          </p>
        </div>
      </form>

      <section aria-labelledby="results">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h1 id="results" className="text-3xl font-extrabold">Your takes</h1>
          <p className="text-sm text-mist">
            {hosted ? 'Real video from the Lumora cloud generator.' : real ? 'Real video from your connected generator.' : <>Preview mode. <Link to="/settings" className="text-lilac underline underline-offset-4">Connect a generator</Link> for real AI video.</>}
          </p>
        </div>
        {recent.length ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {recent.map((c) => (
              <ClipCard key={c.id} clip={c} onOpen={setOpen} onDismiss={(x) => removeClip(email, x.id)} />
            ))}
          </div>
        ) : (
          <div className="grid min-h-[22rem] place-items-center rounded-3xl border border-dashed border-line p-8 text-center">
            <div>
              <Type className="mx-auto mb-3 text-mist" />
              <p className="text-lg font-semibold">No clips yet</p>
              <p className="mx-auto mt-1 max-w-xs text-mist">Describe a shot on the left and press Generate. Your takes will appear here.</p>
            </div>
          </div>
        )}
        {busyCount > 0 && (
          <p className="mt-4 text-sm text-mist">
            {hosted ? 'Clips keep rendering on the server, so you can close this tab. They will be here when you come back.' : 'Keep this tab open while clips render. Closing it cancels anything still running.'}
          </p>
        )}
        {data.clips.length > 12 && <p className="mt-6 text-center"><Link to="/library" className="text-lilac underline underline-offset-4">See all {data.clips.length} clips in your library</Link></p>}
      </section>

      <ClipModal clip={open} onClose={() => setOpen(null)} />
    </div>
  )
}

void PLANS
