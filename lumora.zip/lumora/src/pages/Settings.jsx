import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { CheckCircle2, Cloud, CloudOff, Loader2 } from 'lucide-react'
import { Button, ErrorNote, Field, Segmented, inputCls } from '../components/ui'
import { useToast } from '../components/Layout'
import { cloudEnabled, deleteAccount, pushCloud, saveSettings, useAccount, useCloudStatus } from '../lib/db'
import { testConnection } from '../lib/generators'
import { callFn } from '../lib/supabase'

export default function Settings() {
  const { email, user, data, plan } = useAccount()
  const toast = useToast()
  const nav = useNavigate()
  const s = data.settings
  const [provider, setProvider] = useState(s.provider)
  const [endpoint, setEndpoint] = useState(s.endpoint)
  const [token, setToken] = useState(s.token)
  const [test, setTest] = useState({ state: 'idle', msg: '' })
  const [confirm, setConfirm] = useState(false)
  const [cloud, setCloud] = useState({ state: 'idle', msg: '' })
  const sync = useCloudStatus()
  const syncLabel = { off: 'Cloud sync is off', idle: 'Connecting', syncing: 'Saving to the cloud', synced: 'All changes saved to the cloud', error: 'Could not reach the cloud. Retrying.' }[sync]

  const save = () => {
    saveSettings(email, { provider, endpoint: endpoint.trim(), token: token.trim() })
    toast('Settings saved')
  }

  const checkCloud = async () => {
    setCloud({ state: 'busy', msg: '' })
    try {
      const r = await callFn('generator-status')
      if (r.online) setCloud({ state: 'ok', msg: 'The cloud generator is online.' })
      else setCloud({ state: 'err', msg: r.configured ? 'The cloud generator is offline right now. Try again later.' : 'No cloud generator has been connected yet. See the README, phase 3.' })
    } catch (e) {
      setCloud({ state: 'err', msg: e.message })
    }
  }

  const runTest = async () => {
    setTest({ state: 'busy', msg: '' })
    try {
      await testConnection({ endpoint: endpoint.trim(), token: token.trim() })
      setTest({ state: 'ok', msg: 'Connected. Your generator answered.' })
    } catch (e) {
      setTest({ state: 'err', msg: e.message })
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Settings</h1>

      <section className="mt-10 rounded-3xl border border-line bg-panel p-6 sm:p-8" aria-labelledby="gen">
        <h2 id="gen" className="text-2xl font-bold">Video generator</h2>
        <p className="mt-2 leading-relaxed text-mist">
          Preview mode draws clips in your browser for free. For real AI video, use the Lumora cloud generator, or run an open model such as Wan 2.1 or LTX-Video yourself on a free GPU and paste its address below. The README has a ready-to-run Colab server.
        </p>
        <div className="mt-5">
          <Segmented
            label="Generator"
            value={provider}
            onChange={setProvider}
            options={[
              { id: 'mock', label: 'Preview (built in)' },
              ...(cloudEnabled ? [{ id: 'hosted', label: 'Lumora cloud (uses credits)' }] : []),
              { id: 'custom', label: 'My own server' },
            ]}
          />
        </div>

        {provider === 'hosted' && (
          <div className="mt-6 space-y-3">
            <p className="leading-relaxed text-mist">
              Clips render on the Lumora cloud GPU and cost credits (1 per second on Flow, 2 on Cine). They keep rendering if you close the tab, and the finished video is saved to your account.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <Button variant="ghost" onClick={checkCloud} disabled={cloud.state === 'busy'}>
                {cloud.state === 'busy' && <Loader2 size={16} className="animate-spin" />} Check that it is online
              </Button>
              {cloud.state === 'ok' && <span className="inline-flex items-center gap-1.5 text-sm text-ok"><CheckCircle2 size={16} /> {cloud.msg}</span>}
            </div>
            {cloud.state === 'err' && <ErrorNote>{cloud.msg}</ErrorNote>}
          </div>
        )}

        {provider === 'custom' && (
          <div className="mt-6 space-y-4">
            <Field label="Server address" hint="For example https://abc123.trycloudflare.com. It must allow requests from this page (CORS).">
              <input className={inputCls} value={endpoint} onChange={(e) => { setEndpoint(e.target.value); setTest({ state: 'idle', msg: '' }) }} placeholder="https://" inputMode="url" />
            </Field>
            <Field label="Access token (optional)" hint="Sent as a Bearer token. Stored only in this browser.">
              <input className={inputCls} type="password" value={token} onChange={(e) => setToken(e.target.value)} autoComplete="off" />
            </Field>
            <div className="flex flex-wrap items-center gap-3">
              <Button variant="ghost" onClick={runTest} disabled={!endpoint.trim() || test.state === 'busy'}>
                {test.state === 'busy' && <Loader2 size={16} className="animate-spin" />} Test connection
              </Button>
              {test.state === 'ok' && <span className="inline-flex items-center gap-1.5 text-sm text-ok"><CheckCircle2 size={16} /> {test.msg}</span>}
            </div>
            {test.state === 'err' && <ErrorNote>{test.msg}</ErrorNote>}
          </div>
        )}
        <Button className="mt-6" onClick={save} disabled={provider === 'custom' && !endpoint.trim()}>Save generator</Button>
      </section>

      <section className="mt-6 rounded-3xl border border-line bg-panel p-6 sm:p-8" aria-labelledby="acct">
        <h2 id="acct" className="text-2xl font-bold">Account</h2>
        <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-6 gap-y-2">
          <dt className="text-mist">Name</dt><dd>{user.name}</dd>
          <dt className="text-mist">Email</dt><dd className="break-all">{user.email}</dd>
          <dt className="text-mist">Credits</dt><dd>{data.credits} left today, refilling to {plan.daily} each day <Link to="/credits" className="ml-2 text-lilac underline underline-offset-4">How credits work</Link></dd>
          <dt className="text-mist">Clips</dt><dd>{data.clips.length} saved</dd>
          <dt className="text-mist">Storage</dt>
          <dd className={`inline-flex items-center gap-2 ${sync === 'error' ? 'text-[#ffd5dd]' : ''}`} role="status">
            {cloudEnabled ? <Cloud size={16} className={sync === 'synced' ? 'text-ok' : 'text-mist'} /> : <CloudOff size={16} className="text-mist" />}
            {cloudEnabled ? syncLabel : 'This browser only'}
            {cloudEnabled && sync === 'error' && <button type="button" onClick={() => pushCloud()} className="text-lilac underline underline-offset-4">Retry now</button>}
          </dd>
        </dl>
        {!cloudEnabled && <p className="mt-4 text-[13px] leading-snug text-mist">Add your Supabase keys (see the README, phase 2) to save accounts and clips to the cloud.</p>}
      </section>

      <section className="mt-6 rounded-3xl border border-tally/30 p-6 sm:p-8" aria-labelledby="danger">
        <h2 id="danger" className="text-2xl font-bold">Delete account</h2>
        <p className="mt-2 text-mist">{cloudEnabled ? 'This erases your clips, videos and profile from the cloud and this browser, then logs you out. It cannot be undone.' : 'This removes your account, clips and settings from this browser. It cannot be undone.'}</p>
        {confirm ? (
          <div className="mt-5 flex flex-wrap gap-3">
            <Button variant="danger" onClick={async () => { await deleteAccount(); nav('/') }}>Yes, delete everything</Button>
            <Button variant="quiet" onClick={() => setConfirm(false)}>Keep my account</Button>
          </div>
        ) : (
          <Button className="mt-5" variant="danger" onClick={() => setConfirm(true)}>Delete account</Button>
        )}
      </section>
    </div>
  )
}
