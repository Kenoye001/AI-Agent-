import { Route, Routes, Navigate, Link } from 'react-router-dom'
import Layout, { RequireAuth } from './components/Layout'
import Landing from './pages/Landing'
import Explore from './pages/Explore'
import Credits from './pages/Credits'
import Auth from './pages/Auth'
import Studio from './pages/Studio'
import Library from './pages/Library'
import Settings from './pages/Settings'
import { Button } from './components/ui'

function NotFound() {
  return (
    <div className="mx-auto max-w-md px-4 py-28 text-center">
      <h1 className="text-5xl font-extrabold">Scene not found</h1>
      <p className="mt-3 text-mist">That page does not exist. Head back to the start.</p>
      <Button as={Link} to="/" className="mt-6">Go home</Button>
    </div>
  )
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Landing />} />
        <Route path="explore" element={<Explore />} />
        <Route path="credits" element={<Credits />} />
        <Route path="pricing" element={<Navigate to="/credits" replace />} />
        <Route path="login" element={<Auth mode="login" />} />
        <Route path="signup" element={<Auth mode="signup" />} />
        <Route path="studio" element={<RequireAuth><Studio /></RequireAuth>} />
        <Route path="library" element={<RequireAuth><Library /></RequireAuth>} />
        <Route path="settings" element={<RequireAuth><Settings /></RequireAuth>} />
        <Route path="home" element={<Navigate to="/" replace />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
