-- Lumora phase 3: server-enforced daily credits and the generator registry. Everything is free: there are
-- no plans, no payments and no billing data anywhere.
-- Run this AFTER schema.sql, once, in the Supabase SQL editor. It is safe to run again.
--
-- After this migration the browser can no longer change credits. Only the
-- edge functions (which use the service role) can, through the functions below.

-- ---------- remove billing leftovers (only matters if an earlier version of this file was run) ----------

drop function if exists public.apply_subscription(uuid, text, text, text);
drop function if exists public.apply_subscription_by_customer(text, text, text);
alter table public.profiles drop column if exists stripe_customer_id;
alter table public.profiles drop column if exists stripe_subscription_id;

-- ---------- lock the sensitive columns away from the browser ----------

revoke all on public.profiles from anon;
revoke all on public.clips    from anon;
revoke insert, delete, update on public.profiles from authenticated;
grant update (name, settings) on public.profiles to authenticated;   -- the only columns a user may edit
drop policy if exists "profiles: insert own" on public.profiles;
drop policy if exists "profiles: delete own" on public.profiles;

-- ---------- server-only tables (no policies, no grants: the browser cannot see them at all) ----------

create table if not exists public.job_ledger (
  clip_id       text primary key,
  user_id       uuid not null references auth.users (id) on delete cascade,
  cost          integer not null check (cost >= 0),
  state         text not null default 'running' check (state in ('running', 'done', 'refunded')),
  generator_job text,
  created_at    timestamptz not null default now()
);
create index if not exists job_ledger_user_state_idx on public.job_ledger (user_id, state);

create table if not exists public.app_config (
  key        text primary key,
  value      text not null,
  updated_at timestamptz not null default now()
);

alter table public.job_ledger enable row level security;
alter table public.app_config enable row level security;
revoke all on public.job_ledger from anon, authenticated;
revoke all on public.app_config from anon, authenticated;

-- ---------- the rules everyone plays by (keep in step with src/lib/presets.js) ----------
-- To give people more, change the numbers here and in presets.js. Free GPUs are slow, so keep them modest.

drop function if exists public.plan_limits(text);
create or replace function public.app_limits()
returns table (daily integer, max_duration integer, max_batch integer)
language sql immutable
as $$ select 120, 60, 2 $$;

-- ---------- functions the signed-in browser may call ----------

-- Tops up today's credits once per UTC day. The only way a browser can gain credits.
create or replace function public.claim_daily_refill()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid   uuid := auth.uid();
  today text := to_char(now() at time zone 'utc', 'YYYY-MM-DD');
  p     public.profiles;
  lim   record;
begin
  if uid is null then raise exception 'not_authenticated' using errcode = '28000'; end if;
  select * into p from public.profiles where id = uid for update;
  if not found then raise exception 'no_profile' using errcode = 'P0002'; end if;
  if p.refill_on <> today then
    select * into lim from public.app_limits();
    update public.profiles set credits = greatest(credits, lim.daily), refill_on = today
      where id = uid returning * into p;
  end if;
  return jsonb_build_object('plan', p.plan, 'credits', p.credits, 'refill_on', p.refill_on);
end;
$$;

-- Creates the profile row if it is missing (for accounts that predate the signup trigger).
create or replace function public.ensure_profile(p_name text default '')
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated' using errcode = '28000'; end if;
  insert into public.profiles (id, name) values (auth.uid(), coalesce(p_name, '')) on conflict (id) do nothing;
end;
$$;

-- ---------- functions only the edge functions may call (service role) ----------

-- Validates plan limits, charges the full cost atomically and records each job. All or nothing.
create or replace function public.reserve_jobs(p_uid uuid, p_jobs jsonb)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  p     public.profiles;
  lim   record;
  j     jsonb;
  n     integer;
  total integer := 0;
  rate  integer;
  dur   integer;
  mdl   text;
  cost  integer;
begin
  select * into p from public.profiles where id = p_uid for update;
  if not found then raise exception 'no_profile' using errcode = 'P0002'; end if;
  select * into lim from public.app_limits();

  if jsonb_typeof(p_jobs) <> 'array' then raise exception 'bad_request: jobs must be a list'; end if;
  n := jsonb_array_length(p_jobs);
  if n < 1 then raise exception 'bad_request: no clips'; end if;
  if n > lim.max_batch then raise exception 'plan_limit: you can make up to % clips per run', lim.max_batch; end if;

  for j in select * from jsonb_array_elements(p_jobs) loop
    if coalesce(j ->> 'id', '') !~ '^[a-z0-9]{6,32}$' then raise exception 'bad_request: invalid clip id'; end if;
    mdl := coalesce(j ->> 'model', 'flow');
    if mdl not in ('flow', 'cine') then raise exception 'bad_request: unknown model'; end if;
    begin dur := (j ->> 'duration')::integer; exception when others then dur := null; end;
    if dur is null or dur < 1 or dur > lim.max_duration then
      raise exception 'plan_limit: clips can be up to % seconds long', lim.max_duration;
    end if;
    total := total + (case mdl when 'cine' then 2 else 1 end) * dur;
  end loop;

  if p.credits < total then
    raise exception 'insufficient_credits: this run costs % credits and you have %', total, p.credits using errcode = 'P0001';
  end if;

  update public.profiles set credits = credits - total where id = p_uid;

  for j in select * from jsonb_array_elements(p_jobs) loop
    mdl  := coalesce(j ->> 'model', 'flow');
    rate := case mdl when 'cine' then 2 else 1 end;
    cost := rate * (j ->> 'duration')::integer;
    insert into public.job_ledger (clip_id, user_id, cost) values (j ->> 'id', p_uid, cost);
    insert into public.clips (id, user_id, data, has_video, created_at)
    values (
      j ->> 'id', p_uid,
      ((coalesce(j -> 'data', '{}'::jsonb) - 'imageDataUrl')
        || jsonb_build_object('status', 'processing', 'cost', cost, 'hosted', true, 'progress', 0, 'stage', 'Queued')),
      false, now()
    );
  end loop;

  return p.credits - total;
end;
$$;

-- Finishes a job exactly once: success keeps the charge, failure refunds it. Calling it again does nothing.
create or replace function public.finalize_job(p_clip_id text, p_ok boolean, p_error text default null, p_has_video boolean default false)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  l public.job_ledger;
  c integer;
begin
  select * into l from public.job_ledger where clip_id = p_clip_id for update;
  if not found then raise exception 'unknown_job' using errcode = 'P0002'; end if;

  if l.state = 'running' then
    if p_ok then
      update public.job_ledger set state = 'done' where clip_id = p_clip_id;
      update public.clips
        set data = data || jsonb_build_object('status', 'done', 'progress', 1, 'stage', 'Done', 'hasVideo', coalesce(p_has_video, false)),
            has_video = coalesce(p_has_video, false)
        where id = p_clip_id and user_id = l.user_id;
    else
      update public.job_ledger set state = 'refunded' where clip_id = p_clip_id;
      update public.profiles set credits = credits + l.cost where id = l.user_id;
      update public.clips
        set data = data || jsonb_build_object('status', 'failed', 'progress', 0,
              'error', coalesce(p_error, 'The generator could not finish this clip. Your credits were returned.')),
            has_video = false
        where id = p_clip_id and user_id = l.user_id;
    end if;
  end if;

  select credits into c from public.profiles where id = l.user_id;
  return c;
end;
$$;

create or replace function public.set_job_generator(p_clip_id text, p_job text)
returns void
language sql
security definer
set search_path = public
as $$
  update public.job_ledger set generator_job = p_job where clip_id = p_clip_id and state = 'running';
$$;

-- Refunds jobs that have been running too long (the generator probably went offline). Returns how many.
create or replace function public.refund_stale_jobs(p_uid uuid, p_minutes integer default 180)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  n integer := 0;
begin
  for r in select clip_id from public.job_ledger
           where user_id = p_uid and state = 'running' and created_at < now() - make_interval(mins => p_minutes)
  loop
    perform public.finalize_job(r.clip_id, false, 'The generator took too long, so this clip was canceled and your credits were returned.', false);
    n := n + 1;
  end loop;
  return n;
end;
$$;

-- ---------- who may run what ----------

revoke execute on function
  public.reserve_jobs(uuid, jsonb),
  public.finalize_job(text, boolean, text, boolean),
  public.set_job_generator(text, text),
  public.refund_stale_jobs(uuid, integer)
  from public, anon, authenticated;
grant execute on function
  public.reserve_jobs(uuid, jsonb),
  public.finalize_job(text, boolean, text, boolean),
  public.set_job_generator(text, text),
  public.refund_stale_jobs(uuid, integer)
  to service_role;

revoke execute on function public.claim_daily_refill(), public.ensure_profile(text) from public, anon;
grant  execute on function public.claim_daily_refill(), public.ensure_profile(text) to authenticated;
