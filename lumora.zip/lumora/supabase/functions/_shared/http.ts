export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

export const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

export const fail = (status: number, message: string) => json({ error: message }, status)

// Wraps a handler with CORS preflight, a method check and a safe catch-all.
export function wrap(handler: (req: Request) => Promise<Response>, method = 'POST') {
  return async (req: Request): Promise<Response> => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
    if (req.method !== method) return fail(405, `Use ${method}.`)
    try {
      return await handler(req)
    } catch (e) {
      console.error('function error:', e)
      return fail(500, 'Something went wrong on our side. Try again in a moment.')
    }
  }
}

export function startServer(handler: (req: Request) => Promise<Response>) {
  // @ts-ignore: the Deno global only exists on Supabase
  if (typeof Deno !== 'undefined') Deno.serve(handler)
}

// Turns the plain-text errors raised by supabase/phase3.sql into an HTTP status and a friendly message.
export function mapDbError(message: string): [number, string] {
  const m = /^(insufficient_credits|plan_limit|bad_request): (.*)$/s.exec(message || '')
  if (m) return [m[1] === 'insufficient_credits' ? 402 : m[1] === 'plan_limit' ? 403 : 400, m[2]]
  if (/duplicate key/i.test(message)) return [409, 'One of those clips already exists. Try again.']
  if (/no_profile/.test(message)) return [404, 'Your profile is missing. Log out and back in.']
  return [500, 'Could not start generation. Try again in a moment.']
}
