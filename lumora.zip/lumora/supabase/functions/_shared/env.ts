// Reads a setting from the Supabase function environment (or process.env when run under Node for tests).
export function env(name: string): string | undefined {
  // @ts-ignore: the Deno global only exists on Supabase
  const d = typeof Deno !== 'undefined' ? Deno.env.get(name) : undefined
  // @ts-ignore: process only exists under Node
  return d ?? (typeof process !== 'undefined' ? process.env[name] : undefined) ?? undefined
}
