import { createClient } from 'npm:@supabase/supabase-js@2'
import { env } from './env.ts'

let cached: any = null

// Service-role client: bypasses row level security, so it must only ever run inside these functions.
export function admin(): any {
  if (!cached) {
    cached = createClient(env('SUPABASE_URL')!, env('SUPABASE_SERVICE_ROLE_KEY')!, {
      auth: { persistSession: false, autoRefreshToken: false },
    })
  }
  return cached
}

// Returns the signed-in user for the request's bearer token, or null.
export async function authUser(req: Request) {
  const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '')
  if (!token) return null
  const { data, error } = await admin().auth.getUser(token)
  if (error || !data?.user) return null
  return data.user as { id: string; email?: string }
}
