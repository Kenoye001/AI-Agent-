import { admin } from './db.ts'
import { env } from './env.ts'

// The generator's public address is stored by the register-generator function (the Colab notebook
// calls it whenever it starts), so a changing tunnel address never needs a redeploy.
export async function generatorBase(): Promise<string | null> {
  const { data } = await admin().from('app_config').select('value').eq('key', 'generator_url').maybeSingle()
  const v = data?.value || env('GENERATOR_URL') || null
  return v ? String(v).replace(/\/+$/, '') : null
}

export function gfetch(base: string, path: string, init: RequestInit = {}, timeoutMs = 20000) {
  const headers = new Headers(init.headers)
  const token = env('GENERATOR_TOKEN')
  if (token) headers.set('Authorization', `Bearer ${token}`)
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json')
  return fetch(base + path, { ...init, headers, signal: AbortSignal.timeout(timeoutMs) })
}
