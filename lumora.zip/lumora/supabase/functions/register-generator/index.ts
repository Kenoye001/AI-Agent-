// Called by the Colab notebook each time it starts, so the app always knows the current tunnel address.
import { admin } from '../_shared/db.ts'
import { env } from '../_shared/env.ts'
import { fail, json, startServer, wrap } from '../_shared/http.ts'
import { gfetch } from '../_shared/generator.ts'

function same(a: string, b: string) {
  if (a.length !== b.length) return false
  let d = 0
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return d === 0
}

export const handler = wrap(async (req) => {
  const key = env('REGISTER_KEY')
  if (!key) return fail(503, 'REGISTER_KEY is not set on the server.')
  if (!same(req.headers.get('x-register-key') || '', key)) return fail(401, 'Wrong register key.')

  const { url } = (await req.json().catch(() => ({}))) as { url?: string }
  let base: string
  try {
    const u = new URL(String(url))
    if (u.protocol !== 'https:' && u.hostname !== 'localhost' && u.hostname !== '127.0.0.1') throw new Error('https only')
    base = u.origin
  } catch {
    return fail(400, 'Send {"url": "https://..."}.')
  }

  try {
    const res = await gfetch(base, '/health', {}, 10000)
    if (!res.ok) throw new Error(`health ${res.status}`)
  } catch {
    return fail(400, 'That address did not answer /health. Is the generator running, and does GENERATOR_TOKEN match?')
  }

  const { error } = await admin().from('app_config').upsert({ key: 'generator_url', value: base, updated_at: new Date().toISOString() })
  if (error) throw error
  return json({ ok: true, url: base })
})

startServer(handler)
