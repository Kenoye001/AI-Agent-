// Deletes everything about a person: removes their videos, then deletes the sign-in itself.
import { admin, authUser } from '../_shared/db.ts'
import { fail, json, startServer, wrap } from '../_shared/http.ts'

export const handler = wrap(async (req) => {
  const user = await authUser(req)
  if (!user) return fail(401, 'Log in first.')
  const db = admin()

  const listed = await db.storage.from('videos').list(user.id, { limit: 1000 })
  if (listed.data?.length) await db.storage.from('videos').remove(listed.data.map((f: any) => `${user.id}/${f.name}`))

  const { error } = await db.auth.admin.deleteUser(user.id) // cascades to profile, clips and the job ledger
  if (error) throw error
  return json({ ok: true })
})

startServer(handler)
