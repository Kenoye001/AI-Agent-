// Lets the app show whether the cloud generator is online before someone spends credits.
import { authUser } from '../_shared/db.ts'
import { fail, json, startServer, wrap } from '../_shared/http.ts'
import { generatorBase, gfetch } from '../_shared/generator.ts'

export const handler = wrap(async (req) => {
  if (!(await authUser(req))) return fail(401, 'Log in first.')
  const base = await generatorBase()
  if (!base) return json({ configured: false, online: false })
  try {
    const res = await gfetch(base, '/health', {}, 5000)
    return json({ configured: true, online: res.ok })
  } catch {
    return json({ configured: true, online: false })
  }
})

startServer(handler)
