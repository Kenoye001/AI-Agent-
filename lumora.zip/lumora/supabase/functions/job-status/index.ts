// Checks one clip. When the generator finishes, copies the video into the user's private storage
// folder and settles the charge. Safe to call repeatedly (finishing is idempotent).
import { admin, authUser } from '../_shared/db.ts'
import { fail, json, startServer, wrap } from '../_shared/http.ts'
import { generatorBase, gfetch } from '../_shared/generator.ts'

const MAX_AGE_MS = 180 * 60 * 1000 // one GPU renders clips one at a time and a one minute clip takes a long while
const MAX_BYTES = 60 * 1024 * 1024

export const handler = wrap(async (req) => {
  const user = await authUser(req)
  if (!user) return fail(401, 'Log in to check your clips.')
  const { id } = (await req.json().catch(() => ({}))) as { id?: string }
  if (!id || !/^[a-z0-9]{6,32}$/.test(id)) return fail(400, 'Missing clip id.')

  const db = admin()
  const { data: job } = await db.from('job_ledger').select('*').eq('clip_id', id).eq('user_id', user.id).maybeSingle()
  if (!job) return fail(404, 'That clip was not started on the cloud generator.')

  const credits = async () => (await db.from('profiles').select('credits').eq('id', user.id).maybeSingle()).data?.credits ?? 0
  const finish = async (ok: boolean, error: string | null, hasVideo = false) => {
    const r = await db.rpc('finalize_job', { p_clip_id: id, p_ok: ok, p_error: error, p_has_video: hasVideo })
    return typeof r.data === 'number' ? r.data : await credits()
  }

  if (job.state === 'done') return json({ status: 'done', credits: await credits() })
  if (job.state === 'refunded') return json({ status: 'failed', error: 'This clip failed and your credits were returned.', credits: await credits() })

  if (Date.now() - new Date(job.created_at).getTime() > MAX_AGE_MS) {
    const c = await finish(false, 'The generator took too long, so this clip was canceled and your credits were returned.')
    return json({ status: 'failed', error: 'The generator took too long. Your credits were returned.', credits: c })
  }

  const base = await generatorBase()
  if (!base || !job.generator_job) return json({ status: 'running', progress: 0.05, stage: 'Waiting for the generator', credits: await credits() })

  let videoPath: string | null = null
  if (job.generator_job.startsWith('video:')) {
    videoPath = job.generator_job.slice(6)
  } else {
    let g: any
    try {
      const res = await gfetch(base, `/jobs/${encodeURIComponent(job.generator_job)}`)
      if (!res.ok) throw new Error(`status ${res.status}`)
      g = await res.json()
    } catch (e) {
      console.error('poll failed', id, String(e))
      return json({ status: 'running', progress: 0.05, stage: 'Waiting for the generator', credits: await credits() })
    }
    if (g.status === 'failed') {
      console.error('generator reported failure', id, g.error)
      const c = await finish(false, 'The generator could not finish this clip. Your credits were returned.')
      return json({ status: 'failed', error: 'The generator could not finish this clip. Your credits were returned.', credits: c })
    }
    if (g.status !== 'done' || !g.video_url) {
      const stage = g.status === 'queued' ? 'Waiting in the generator queue' : 'Generating video'
      return json({ status: 'running', progress: Math.min(0.9, Math.max(0.08, Number(g.progress) || 0.3)), stage, credits: await credits() })
    }
    videoPath = g.video_url
  }

  // Finished: fetch the file and keep it in the user's own folder.
  try {
    const url = /^https?:\/\//i.test(videoPath!) ? videoPath! : base + (videoPath!.startsWith('/') ? '' : '/') + videoPath
    if (/^https?:\/\//i.test(url) && new URL(url).origin !== new URL(base).origin) throw new Error('video on a different host')
    const res = await gfetch(base, url.slice(base.length), {}, 90000)
    if (!res.ok) throw new Error(`download status ${res.status}`)
    const bytes = new Uint8Array(await res.arrayBuffer())
    if (!bytes.length || bytes.length > MAX_BYTES) throw new Error(`bad video size ${bytes.length}`)
    const up = await db.storage.from('videos').upload(`${user.id}/${id}`, bytes, { upsert: true, contentType: res.headers.get('content-type') || 'video/mp4' })
    if (up.error) throw up.error
  } catch (e) {
    console.error('store failed', id, String(e))
    return json({ status: 'running', progress: 0.95, stage: 'Saving the clip', credits: await credits() }) // retried on the next poll
  }
  return json({ status: 'done', credits: await finish(true, null, true) })
})

startServer(handler)
