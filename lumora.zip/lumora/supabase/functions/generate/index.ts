// Starts 1-4 clips on the cloud generator. The browser never sees the generator address or token,
// and credits are charged here, on the server, before anything is sent to the GPU.
import { admin, authUser } from '../_shared/db.ts'
import { fail, json, mapDbError, startServer, wrap } from '../_shared/http.ts'
import { generatorBase, gfetch } from '../_shared/generator.ts'

const ASPECTS = ['16:9', '9:16', '1:1', '4:3', '21:9']
const ID = /^[a-z0-9]{6,32}$/
const TAG = /^[a-z0-9_]{1,24}$/

export const handler = wrap(async (req) => {
  const user = await authUser(req)
  if (!user) return fail(401, 'Log in to generate clips.')

  const body = await req.json().catch(() => null)
  const clips: any[] = Array.isArray(body?.clips) ? body.clips : []
  if (clips.length < 1 || clips.length > 4) return fail(400, 'Send between 1 and 4 clips.')

  for (const c of clips) {
    const ok =
      ID.test(String(c?.id)) && typeof c.prompt === 'string' && c.prompt.length <= 600 &&
      typeof c.genPrompt === 'string' && c.genPrompt.length <= 1500 &&
      TAG.test(String(c.style)) && TAG.test(String(c.camera)) && ASPECTS.includes(c.aspect) &&
      Number.isInteger(c.duration) && Number.isInteger(c.seed) && c.seed >= 0 && c.seed < 2 ** 31 &&
      ['flow', 'cine'].includes(c.model) && (c.mode === 'text' || c.mode === 'image') &&
      (c.negative == null || (typeof c.negative === 'string' && c.negative.length <= 300)) &&
      (c.image == null || (typeof c.image === 'string' && c.image.length <= 2_000_000))
    if (!ok) return fail(400, 'That request looks malformed. Refresh the page and try again.')
  }

  const base = await generatorBase()
  if (!base) return fail(503, 'The Lumora cloud generator is offline right now. Use a preview clip, or try again later.')

  const db = admin()
  await db.rpc('refund_stale_jobs', { p_uid: user.id, p_minutes: 60 }) // free up credits stuck on dead jobs

  const resolution = '720p' // free GPUs: one size for everyone

  // Charge first (all or nothing). The metadata saved with each clip is built here, not copied from the browser.
  const now = Date.now()
  const jobs = clips.map((c, i) => ({
    id: c.id, model: c.model, duration: c.duration,
    data: {
      id: c.id, prompt: c.prompt, negative: c.negative || '', style: c.style, camera: c.camera, aspect: c.aspect,
      duration: c.duration, model: c.model, seed: c.seed, mode: c.mode, createdAt: now + i, favorite: false,
      hasVideo: false, real: true,
    },
  }))
  const reserved = await db.rpc('reserve_jobs', { p_uid: user.id, p_jobs: jobs })
  if (reserved.error) {
    const [status, message] = mapDbError(reserved.error.message)
    return fail(status, message)
  }
  let credits: number = reserved.data

  const results = await Promise.all(
    clips.map(async (c) => {
      try {
        const res = await gfetch(base, '/generate', {
          method: 'POST',
          body: JSON.stringify({
            prompt: c.genPrompt, negative_prompt: c.negative || '', style: c.style, camera: c.camera, aspect: c.aspect,
            duration: c.duration, seed: c.seed, model: c.model, resolution, image: c.image || null,
          }),
        })
        if (!res.ok) throw new Error(`generator answered ${res.status}`)
        const out = await res.json()
        const handle = out.job_id ? String(out.job_id) : out.video_url ? `video:${out.video_url}` : ''
        if (!handle) throw new Error('generator returned no job')
        await db.rpc('set_job_generator', { p_clip_id: c.id, p_job: handle })
        return { id: c.id, ok: true }
      } catch (e) {
        console.error('submit failed', c.id, String(e))
        const message = 'The cloud generator did not accept this clip. Your credits were returned.'
        const f = await db.rpc('finalize_job', { p_clip_id: c.id, p_ok: false, p_error: message, p_has_video: false })
        if (typeof f.data === 'number') credits = f.data
        return { id: c.id, ok: false, error: message }
      }
    }),
  )

  // Refunds may have changed the balance: read the final figure.
  const { data: after } = await db.from('profiles').select('credits').eq('id', user.id).maybeSingle()
  return json({ credits: after?.credits ?? credits, jobs: results })
})

startServer(handler)
