-- Lumora phase 2: run this once in the Supabase SQL editor (Project > SQL Editor > New query).
-- It creates the tables, row level security, a signup trigger and the private video bucket.

-- ---------- tables ----------

create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  name        text not null default '',
  plan        text not null default 'free' check (plan in ('free', 'creator', 'studio')),
  credits     integer not null default 120 check (credits >= 0),
  refill_on   text not null default '',          -- day of the last daily refill, set by the app
  settings    jsonb not null default '{}'::jsonb, -- generator provider + endpoint (never the token)
  created_at  timestamptz not null default now()
);

create table if not exists public.clips (
  id          text primary key,
  user_id     uuid not null references auth.users (id) on delete cascade,
  data        jsonb not null,                     -- prompt, style, camera, status, and so on
  has_video   boolean not null default false,     -- true when a real video file is in storage
  created_at  timestamptz not null default now()
);

create index if not exists clips_user_created_idx on public.clips (user_id, created_at desc);

-- ---------- row level security: people only ever see and change their own rows ----------

alter table public.profiles enable row level security;
alter table public.clips    enable row level security;

drop policy if exists "profiles: read own"   on public.profiles;
drop policy if exists "profiles: insert own" on public.profiles;
drop policy if exists "profiles: update own" on public.profiles;
drop policy if exists "profiles: delete own" on public.profiles;
create policy "profiles: read own"   on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles: insert own" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles: update own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles: delete own" on public.profiles for delete to authenticated using (id = auth.uid());

drop policy if exists "clips: read own"   on public.clips;
drop policy if exists "clips: insert own" on public.clips;
drop policy if exists "clips: update own" on public.clips;
drop policy if exists "clips: delete own" on public.clips;
create policy "clips: read own"   on public.clips for select to authenticated using (user_id = auth.uid());
create policy "clips: insert own" on public.clips for insert to authenticated with check (user_id = auth.uid());
create policy "clips: update own" on public.clips for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "clips: delete own" on public.clips for delete to authenticated using (user_id = auth.uid());

-- ---------- create a profile automatically when someone signs up ----------

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- private bucket for generated videos; each user owns the folder named after their id ----------

insert into storage.buckets (id, name, public)
values ('videos', 'videos', false)
on conflict (id) do nothing;

drop policy if exists "videos: read own"   on storage.objects;
drop policy if exists "videos: insert own" on storage.objects;
drop policy if exists "videos: update own" on storage.objects;
drop policy if exists "videos: delete own" on storage.objects;
create policy "videos: read own"   on storage.objects for select to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "videos: insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "videos: update own" on storage.objects for update to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "videos: delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
