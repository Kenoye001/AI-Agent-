# Backend tests

These run on your machine with no Supabase or GPU account.

```bash
npm run test:sql         # schema.sql + phase3.sql on real Postgres (PGlite): row level security,
                         # locked credit columns, charging, refunds
npm run test:functions   # the real edge function code against a stand-in Supabase, GPU generator
                         # (limits, refunds, delete account)
npm run test:backend     # both
```

`mock-backend.mjs` is a small Supabase look-alike backed by that same Postgres: every request runs under
the caller's role, so the database rules apply exactly as they will on Supabase. It is a test aid, not a
substitute for trying the real thing: the first real deploy is still the final check.
