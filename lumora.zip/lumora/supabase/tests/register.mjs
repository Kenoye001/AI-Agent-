// Lets Node run the edge functions unchanged: maps Deno's "npm:pkg@version" imports to plain package names.
import { register } from 'node:module'
register('./loader.mjs', import.meta.url)
