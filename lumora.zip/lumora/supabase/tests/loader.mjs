export async function resolve(specifier, context, next) {
  if (specifier.startsWith('npm:')) specifier = specifier.slice(4).replace(/(?<=.)@[^/@]+$/, '')
  return next(specifier, context)
}
