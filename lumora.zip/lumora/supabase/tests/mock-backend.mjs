// A stand-in for Supabase + the GPU generator, for tests. The database is real Postgres
// (PGlite) running schema.sql and phase3.sql, and every API request runs under the caller's role,
// so row level security and column privileges are enforced exactly as on Supabase.
//
//   node --import ./register.mjs mock-backend.mjs      (listens on 8097 / 8101 / 8102)
import { PGlite } from '@electric-sql/pglite'
import http from 'node:http'
import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const root = path.join(here, '..')
export const PORTS = { supabase: 8097, generator: 8101 }
export const KEYS = { service: 'service-key', anon: 'anon-test-key', generatorToken: 'gtok', register: 'regkey' }

Object.assign(process.env, {
  SUPABASE_URL: `http://localhost:${PORTS.supabase}`,
  SUPABASE_SERVICE_ROLE_KEY: KEYS.service,
  GENERATOR_TOKEN: KEYS.generatorToken,
  REGISTER_KEY: KEYS.register,
})

// ---------------- database ----------------
const db = new PGlite()
await db.exec(fs.readFileSync(path.join(here, 'stubs.sql'), 'utf8'))
await db.exec(fs.readFileSync(path.join(root, 'schema.sql'), 'utf8'))
await db.exec(fs.readFileSync(path.join(root, 'phase3.sql'), 'utf8'))

let queue = Promise.resolve()
function inRole(role, uid, fn) {
  const run = queue.then(() => db.transaction(async (tx) => {
    await tx.exec(`set local role ${role}`)
    await tx.query(`select set_config('request.jwt.claim.sub', $1, true)`, [uid || ''])
    return fn(tx)
  }))
  queue = run.catch(() => {})
  return run
}
const sudo = (sql, params) => { const run = queue.then(() => db.query(sql, params)); queue = run.catch(() => {}); return run }

// ---------------- shared state ----------------
const tokens = new Map() // access token -> user id
const objects = new Map() // storage path -> Buffer
const state = { confirm: false, genCalls: [], genOffline: false, storageDownloads: 0, rlsDenied: 0 }
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url')
const ident = (s) => { if (!/^[a-z_]+$/.test(s)) throw new Error('bad identifier ' + s); return s }

const readBody = (req) => new Promise((r) => { const c = []; req.on('data', (d) => c.push(d)); req.on('end', () => r(Buffer.concat(c))) })
const cors = (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS')
}
const send = (res, code, obj) => { res.statusCode = code; if (obj !== undefined) { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(obj)) } else res.end() }

function who(req) {
  const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (t === KEYS.service) return { role: 'service_role', uid: null, token: t }
  if (tokens.has(t)) return { role: 'authenticated', uid: tokens.get(t), token: t }
  return { role: 'anon', uid: null, token: t }
}

const session = (u) => {
  const exp = Math.floor(Date.now() / 1000) + 3600
  const at = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub: u.id, email: u.email, role: 'authenticated', aud: 'authenticated', exp })}.${crypto.randomUUID()}`
  tokens.set(at, u.id)
  return { access_token: at, token_type: 'bearer', expires_in: 3600, expires_at: exp, refresh_token: crypto.randomUUID(), user: pub(u) }
}
const pub = (u) => ({ id: u.id, aud: 'authenticated', role: 'authenticated', email: u.email, email_confirmed_at: new Date().toISOString(), user_metadata: u.raw_user_meta_data || {}, app_metadata: {}, created_at: new Date().toISOString() })

// ---------------- PostgREST-style REST ----------------
function filters(url, params) {
  const out = []
  for (const [k, v] of url.searchParams) {
    if (['select', 'order', 'limit', 'on_conflict', 'columns'].includes(k)) continue
    let m
    if ((m = /^eq\.(.*)$/.exec(v))) { params.push(m[1]); out.push(`${ident(k)}::text = $${params.length}`) }
    else if ((m = /^in\.\((.*)\)$/.exec(v))) { const list = m[1].split(',').map((s) => s.replace(/^"|"$/g, '')); const ph = list.map((x) => (params.push(x), `$${params.length}`)); out.push(`${ident(k)}::text in (${ph.join(',')})`) }
  }
  return out.length ? ' where ' + out.join(' and ') : ''
}
const val = (params, v) => { params.push(v !== null && typeof v === 'object' ? JSON.stringify(v) : v); return typeof v === 'object' && v !== null ? `$${params.length}::jsonb` : `$${params.length}` }
const PK = { profiles: 'id', clips: 'id', app_config: 'key' }

async function rest(req, res, url, body) {
  const w = who(req)
  const name = url.pathname.replace('/rest/v1/', '')
  try {
    const out = await inRole(w.role, w.uid, async (tx) => {
      if (name.startsWith('rpc/')) {
        const fn = ident(name.slice(4)); const args = JSON.parse(body.toString() || '{}'); const keys = Object.keys(args); const params = []
        const sql = `select public.${fn}(${keys.map((k) => `${ident(k)} => ${val(params, args[k])}`).join(', ')}) as r`
        return { rpc: (await tx.query(sql, params)).rows[0].r }
      }
      const table = ident(name); const params = []
      if (req.method === 'GET') {
        const cols = (url.searchParams.get('select') || '*').split(',').map((c) => (c === '*' ? '*' : ident(c))).join(', ')
        let sql = `select ${cols} from public.${table}${filters(url, params)}`
        const ord = url.searchParams.get('order'); if (ord) { const [c, d] = ord.split('.'); sql += ` order by ${ident(c)} ${d === 'desc' ? 'desc' : 'asc'}` }
        const lim = url.searchParams.get('limit'); if (lim) sql += ` limit ${Number(lim)}`
        return { rows: (await tx.query(sql, params)).rows }
      }
      if (req.method === 'POST') {
        const rows = [].concat(JSON.parse(body.toString() || '[]')); const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))]
        const tuples = rows.map((r) => `(${cols.map((c) => (r[c] === undefined ? 'default' : val(params, r[c]))).join(', ')})`)
        let sql = `insert into public.${table} (${cols.map(ident).join(', ')}) values ${tuples.join(', ')}`
        if (/merge-duplicates/.test(req.headers.prefer || '')) sql += ` on conflict (${PK[table]}) do update set ${cols.filter((c) => c !== PK[table]).map((c) => `${c} = excluded.${c}`).join(', ')}`
        return { rows: (await tx.query(sql + ' returning *', params)).rows, created: true }
      }
      if (req.method === 'PATCH') {
        const patch = JSON.parse(body.toString() || '{}')
        const sets = Object.keys(patch).map((c) => `${ident(c)} = ${val(params, patch[c])}`)
        return { rows: (await tx.query(`update public.${table} set ${sets.join(', ')}${filters(url, params)} returning *`, params)).rows }
      }
      if (req.method === 'DELETE') return { rows: (await tx.query(`delete from public.${table}${filters(url, params)} returning *`, params)).rows }
      throw new Error('unsupported ' + req.method)
    })
    if ('rpc' in out) return out.rpc === null ? send(res, 204) : send(res, 200, out.rpc)
    if (req.method === 'GET') return send(res, 200, out.rows)
    if (/return=representation/.test(req.headers.prefer || '')) return send(res, out.created ? 201 : 200, out.rows)
    return send(res, out.created ? 201 : 204)
  } catch (e) {
    const denied = e.code === '42501'
    if (denied) state.rlsDenied++
    send(res, denied ? 403 : e.code === '23505' ? 409 : 400, { code: e.code, message: e.message, details: null, hint: null })
  }
}

// ---------------- auth / storage / functions ----------------
const multipartFile = (buf, ct) => {
  const m = /boundary=(.+)$/.exec(ct || ''); if (!m) return buf
  const s = buf.toString('latin1'); const start = s.indexOf('\r\n\r\n', s.indexOf('filename')) + 4; const end = s.lastIndexOf('\r\n--' + m[1])
  return buf.subarray(start, end)
}

async function supabaseServer(req, res) {
  cors(req, res)
  if (req.method === 'OPTIONS') return res.end()
  const url = new URL(req.url, 'http://x'); const p = url.pathname; const body = await readBody(req)
  const json = () => { try { return JSON.parse(body.toString() || '{}') } catch { return {} } }
  const w = who(req)

  if (p === '/__confirm') { state.confirm = url.searchParams.get('on') === '1'; return send(res, 200, {}) }
  if (p === '/__gen') { state.genOffline = url.searchParams.get('offline') === '1'; return send(res, 200, {}) }
  if (p === '/__state') return send(res, 200, { ...state, objects: Object.fromEntries([...objects].map(([k, v]) => [k, v.length])) })
  if (p === '/__sql') { const b = json(); try { return send(res, 200, (await sudo(b.sql, b.params || [])).rows) } catch (e) { return send(res, 400, { message: e.message }) } }

  if (p === '/auth/v1/signup') {
    const b = json(); const email = String(b.email).toLowerCase()
    const dup = (await sudo('select id from auth.users where email=$1', [email])).rows[0]
    if (dup) return send(res, 200, pub({ id: crypto.randomUUID(), email }))
    const u = (await sudo('insert into auth.users (email, raw_user_meta_data, password) values ($1,$2::jsonb,$3) returning *', [email, JSON.stringify(b.data || {}), b.password])).rows[0]
    return send(res, 200, state.confirm ? pub(u) : session(u))
  }
  if (p === '/auth/v1/token') {
    const b = json(); const u = (await sudo('select * from auth.users where email=$1 and password=$2', [String(b.email).toLowerCase(), b.password])).rows[0]
    return u ? send(res, 200, session(u)) : send(res, 400, { code: 400, error_code: 'invalid_credentials', msg: 'Invalid login credentials' })
  }
  if (p === '/auth/v1/user') { const u = w.uid && (await sudo('select * from auth.users where id=$1', [w.uid])).rows[0]; return u ? send(res, 200, pub(u)) : send(res, 401, { msg: 'invalid token' }) }
  if (p === '/auth/v1/logout') return send(res, 204)
  let m
  if ((m = /^\/auth\/v1\/admin\/users\/(.+)$/.exec(p)) && req.method === 'GET') {
    if (w.role !== 'service_role') return send(res, 403, { msg: 'not admin' })
    const u = (await sudo('select * from auth.users where id=$1', [m[1]])).rows[0]; return u ? send(res, 200, pub(u)) : send(res, 404, { msg: 'User not found' })
  }
  if ((m = /^\/auth\/v1\/admin\/users\/(.+)$/.exec(p)) && req.method === 'DELETE') {
    if (w.role !== 'service_role') return send(res, 403, { msg: 'not admin' })
    await sudo('delete from auth.users where id=$1', [m[1]]); return send(res, 200, {})
  }

  if (p.startsWith('/rest/v1/')) return rest(req, res, url, body)

  const own = (pathname) => w.role === 'service_role' || (w.uid && pathname.split('/')[0] === w.uid)
  if ((m = /^\/storage\/v1\/object\/videos\/(.+)$/.exec(p)) && ['POST', 'PUT'].includes(req.method)) {
    const k = decodeURIComponent(m[1]); if (!own(k)) { state.rlsDenied++; return send(res, 403, { message: 'new row violates row-level security policy' }) }
    objects.set(k, multipartFile(body, req.headers['content-type'])); return send(res, 200, { Key: 'videos/' + k })
  }
  if ((m = /^\/storage\/v1\/object\/(?:authenticated\/)?videos\/(.+)$/.exec(p)) && req.method === 'GET') {
    const k = decodeURIComponent(m[1]); if (!own(k)) { state.rlsDenied++; return send(res, 403, { message: 'denied' }) }
    if (!objects.has(k)) return send(res, 404, { message: 'Object not found' })
    state.storageDownloads++; res.setHeader('Content-Type', 'video/mp4'); return res.end(objects.get(k))
  }
  if (p === '/storage/v1/object/videos' && req.method === 'DELETE') { for (const x of json().prefixes || []) if (own(x)) objects.delete(x); return send(res, 200, []) }
  if (p === '/storage/v1/object/list/videos') { const pre = json().prefix; return send(res, 200, own(pre + '/x') ? [...objects.keys()].filter((k) => k.startsWith(pre + '/')).map((k) => ({ name: k.slice(pre.length + 1) })) : []) }

  if ((m = /^\/functions\/v1\/([a-z-]+)$/.exec(p))) {
    const file = path.join(root, 'functions', m[1], 'index.ts')
    if (!fs.existsSync(file)) return send(res, 404, { error: 'no such function' })
    const { handler } = await import(pathToFileURL(file).href)
    const headers = new Headers(); for (const [k, v] of Object.entries(req.headers)) if (v && !['host', 'content-length', 'connection'].includes(k)) headers.set(k, String(v))
    const out = await handler(new Request('http://fn' + p, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body }))
    cors(req, res); res.statusCode = out.status; out.headers.forEach((v, k) => res.setHeader(k, v)); return res.end(Buffer.from(await out.arrayBuffer()))
  }
  send(res, 404, { message: `mock: no route ${req.method} ${p}` })
}

// ---------------- fake GPU generator (the Colab server) ----------------
const jobs = new Map()
async function generatorServer(req, res) {
  if (state.genOffline) return req.socket.destroy()
  const url = new URL(req.url, 'http://x'); const body = await readBody(req)
  if (req.headers.authorization !== `Bearer ${KEYS.generatorToken}`) return send(res, 401, { error: 'bad token' })
  if (url.pathname === '/health') return send(res, 200, { ok: true })
  if (url.pathname === '/generate') {
    const b = JSON.parse(body.toString()); state.genCalls.push(b)
    if (/SUBMITFAIL/.test(b.prompt)) return send(res, 500, { error: 'cuda out of memory' })
    const id = 'g' + (jobs.size + 1); jobs.set(id, { polls: 0, fail: /FAILME/.test(b.prompt), slow: /SLOW/.test(b.prompt) }); return send(res, 200, { job_id: id })
  }
  let m
  if ((m = /^\/jobs\/(.+)$/.exec(url.pathname))) {
    const j = jobs.get(m[1]); if (!j) return send(res, 404, { error: 'no job' }); j.polls++
    if (j.fail && j.polls > 1) return send(res, 200, { status: 'failed', error: 'secret internal gpu error details' })
    if (j.slow || j.polls < 2) return send(res, 200, { status: j.polls < 2 ? 'queued' : 'running', progress: 0.4 })
    return send(res, 200, { status: 'done', progress: 1, video_url: `/files/${m[1]}.mp4` })
  }
  if (url.pathname.startsWith('/files/')) { res.setHeader('Content-Type', 'video/mp4'); return res.end(Buffer.from('FAKE-MP4-DATA')) }
  send(res, 404, {})
}

export function start() {
  return Promise.all([
    new Promise((r) => http.createServer((q, s) => supabaseServer(q, s).catch((e) => { console.error(e); send(s, 500, { message: String(e) }) })).listen(PORTS.supabase, r)),
    new Promise((r) => http.createServer(generatorServer).listen(PORTS.generator, r)),
  ])
}

if (process.argv[1] === fileURLToPath(import.meta.url)) { await start(); console.log('mock backend up: supabase 8097, generator 8101') }
