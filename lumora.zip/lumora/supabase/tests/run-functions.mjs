// Starts the mock backend in this process, then runs the function tests against it.
import { start } from './mock-backend.mjs'
await start()
await import('./functions.test.mjs')
