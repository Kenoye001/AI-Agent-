// Run against a running mock backend:  node --import ./register.mjs mock-backend.mjs &  then  node functions.test.mjs
import crypto from 'node:crypto'
const API = 'http://localhost:8097'
let fails = 0
const ok = (c, m) => { console.log(c ? 'PASS' : 'FAIL', m); if (!c) fails++ }
const sql = async (q, params = []) => (await (await fetch(API + '/__sql', { method: 'POST', body: JSON.stringify({ sql: q, params }) })).json())
const state = async () => (await fetch(API + '/__state')).json()
const fn = async (name, token, body, headers = {}) => {
  const r = await fetch(`${API}/functions/v1/${name}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body ?? {}) })
  return { status: r.status, json: await r.json().catch(() => null) }
}
let n = 0
const signup = async (name) => {
  const email = `${name}${++n}@example.com`
  const r = await (await fetch(API + '/auth/v1/signup', { method: 'POST', body: JSON.stringify({ email, password: 'password123', data: { name } }) })).json()
  return { token: r.access_token, uid: r.user.id, email }
}
const credits = async (uid) => (await sql('select credits from public.profiles where id=$1', [uid]))[0]?.credits
const clip = (over = {}) => ({ id: 'c' + crypto.randomBytes(5).toString('hex'), prompt: 'a fox', genPrompt: 'a fox. cinematic', negative: '', style: 'cinematic', camera: 'dolly_in', aspect: '16:9', duration: 5, seed: 42, model: 'flow', mode: 'text', image: null, ...over })
const poll = async (token, id, until = ['done', 'failed'], max = 8) => { let r; for (let i = 0; i < max; i++) { r = await fn('job-status', token, { id }); if (until.includes(r.json?.status)) return r; await new Promise((s) => setTimeout(s, 50)) } return r }

// ---------- generator registration ----------
const U = await signup('ann')
let r = await fn('generate', U.token, { clips: [clip()] })
ok(r.status === 503 && /offline/i.test(r.json.error), 'generate says "offline" before any generator is registered')
ok((await credits(U.uid)) === 120, 'and charges nothing in that case')
r = await fn('register-generator', null, { url: 'http://localhost:8101' }, { 'x-register-key': 'nope' })
ok(r.status === 401, 'register-generator rejects a wrong key')
r = await fn('register-generator', null, { url: 'ftp://x' }, { 'x-register-key': 'regkey' })
ok(r.status === 400, 'register-generator rejects a bad address')
await fetch(API + '/__gen?offline=1')
r = await fn('register-generator', null, { url: 'http://localhost:8101' }, { 'x-register-key': 'regkey' })
ok(r.status === 400 && /health/.test(r.json.error), 'register-generator refuses an address that does not answer /health')
await fetch(API + '/__gen?offline=0')
r = await fn('register-generator', null, { url: 'http://localhost:8101/some/path' }, { 'x-register-key': 'regkey' })
ok(r.status === 200 && r.json.url === 'http://localhost:8101', 'register-generator stores the origin')
r = await fn('generator-status', U.token, {})
ok(r.json.online === true && r.json.configured === true, 'generator-status reports online')
await fetch(API + '/__gen?offline=1'); r = await fn('generator-status', U.token, {}); await fetch(API + '/__gen?offline=0')
ok(r.json.online === false, 'generator-status reports offline when it is down')
ok((await fn('generator-status', null, {})).status === 401, 'generator-status needs a login')

// ---------- generate: validation and auth ----------
ok((await fn('generate', null, { clips: [clip()] })).status === 401, 'generate needs a login')
ok((await fn('generate', 'forged.token.here', { clips: [clip()] })).status === 401, 'generate rejects a forged token')
ok((await fn('generate', U.token, { clips: [] })).status === 400, 'generate rejects an empty list')
ok((await fn('generate', U.token, { clips: [clip({ id: '../../etc' })] })).status === 400, 'generate rejects a path-traversal clip id')
ok((await fn('generate', U.token, { clips: [clip({ aspect: '99:1' })] })).status === 400, 'generate rejects an unknown aspect')
ok((await fn('generate', U.token, { clips: [clip({ prompt: 'x'.repeat(601) })] })).status === 400, 'generate rejects an oversized prompt')
ok((await fn('generate', U.token, 'not json')).status === 400, 'generate rejects a non-JSON body')
ok((await credits(U.uid)) === 120, 'none of the bad requests charged anything')

// ---------- generate: limits and credits (server-side) ----------
r = await fn('generate', U.token, { clips: [clip({ duration: 61 })] })
ok(r.status === 403 && /60 seconds/.test(r.json.error), 'over-long clip refused with a clear message')
r = await fn('generate', U.token, { clips: [clip(), clip(), clip()] })
ok(r.status === 403 && /2 clips/.test(r.json.error), 'free plan: 3 clips per run refused')
await sql('update public.profiles set credits=4 where id=$1', [U.uid])
r = await fn('generate', U.token, { clips: [clip()] })
ok(r.status === 402 && /costs 5 credits and you have 4/.test(r.json.error), 'not enough credits: 402 with exact numbers')
ok((await credits(U.uid)) === 4, 'and nothing was charged')
await sql('update public.profiles set credits=120 where id=$1', [U.uid])

// ---------- generate: the happy path ----------
const c1 = clip({ prompt: 'a fox on ice', genPrompt: 'a fox on ice. cinematic look', image: null })
r = await fn('generate', U.token, { clips: [c1] })
ok(r.status === 200 && r.json.credits === 115 && r.json.jobs[0].ok, 'generate charges 5 credits for a 5 second Flow clip')
let ledger = (await sql('select * from public.job_ledger where clip_id=$1', [c1.id]))[0]
ok(ledger.state === 'running' && ledger.user_id === U.uid && ledger.cost === 5 && ledger.generator_job, 'ledger row created with the generator job id')
const row = (await sql('select data from public.clips where id=$1', [c1.id]))[0]
ok(row.data.status === 'processing' && row.data.hosted === true && row.data.prompt === 'a fox on ice', 'clip row created server-side as processing')
let st = await state()
const sent = st.genCalls.at(-1)
ok(sent.prompt === 'a fox on ice. cinematic look' && sent.resolution === '720p' && sent.duration === 5 && sent.model === 'flow', 'generator received the composed prompt and the plan resolution (720p on free)')

// ---------- job-status ----------
ok((await fn('job-status', null, { id: c1.id })).status === 401, 'job-status needs a login')
const V = await signup('mallory')
ok((await fn('job-status', V.token, { id: c1.id })).status === 404, "another user cannot poll someone else's clip")
r = await poll(U.token, c1.id, ['running', 'done'], 1)
ok(r.json.status === 'running' && typeof r.json.progress === 'number', 'first poll: still running, with progress')
r = await poll(U.token, c1.id)
ok(r.json.status === 'done' && r.json.credits === 115, 'poll eventually reports done, credits unchanged')
st = await state()
ok(st.objects[`${U.uid}/${c1.id}`] === 'FAKE-MP4-DATA'.length, "video copied into the user's own storage folder")
ledger = (await sql('select state from public.job_ledger where clip_id=$1', [c1.id]))[0]
const done = (await sql('select data, has_video from public.clips where id=$1', [c1.id]))[0]
ok(ledger.state === 'done' && done.data.status === 'done' && done.has_video === true && done.data.hasVideo === true, 'ledger and clip row both marked done with a video')
r = await fn('job-status', U.token, { id: c1.id })
ok(r.json.status === 'done' && (await credits(U.uid)) === 115, 'polling a finished clip again is harmless')

// ---------- failures refund ----------
const c2 = clip({ prompt: 'FAILME please', genPrompt: 'FAILME please' })
await fn('generate', U.token, { clips: [c2] })
ok((await credits(U.uid)) === 110, 'second clip charged')
r = await poll(U.token, c2.id)
ok(r.json.status === 'failed' && r.json.credits === 115, 'generator failure refunds the credits')
ok(!/secret internal/.test(JSON.stringify(r.json)), "the generator's internal error text is not leaked to the browser")
ok((await sql('select data from public.clips where id=$1', [c2.id]))[0].data.status === 'failed', 'clip row marked failed')
r = await fn('job-status', U.token, { id: c2.id })
ok(r.json.status === 'failed' && (await credits(U.uid)) === 115, 'a refunded clip is never refunded twice')

const c3 = clip({ prompt: 'SUBMITFAIL now', genPrompt: 'SUBMITFAIL now' })
r = await fn('generate', U.token, { clips: [c3] })
ok(r.status === 200 && r.json.jobs[0].ok === false && r.json.credits === 115, 'generator rejecting the submit refunds immediately')

// ---------- batch: partial failure ----------
const b1 = clip(), b2 = clip({ prompt: 'SUBMITFAIL', genPrompt: 'SUBMITFAIL' })
r = await fn('generate', U.token, { clips: [b1, b2] })
ok(r.json.jobs[0].ok && !r.json.jobs[1].ok && r.json.credits === 110, 'batch of 2 where one is rejected: only the good one is charged')

// ---------- generator dies mid-job ----------
const c4 = clip({ prompt: 'SLOW one', genPrompt: 'SLOW one' })
await sql('update public.profiles set credits=120 where id=$1', [U.uid])
await fn('generate', U.token, { clips: [c4] })
await fetch(API + '/__gen?offline=1')
r = await fn('job-status', U.token, { id: c4.id })
await fetch(API + '/__gen?offline=0')
ok(r.json.status === 'running', 'a temporarily unreachable generator does not fail the clip')
await sql(`update public.job_ledger set created_at = now() - interval '4 hours' where clip_id=$1`, [c4.id])
r = await fn('job-status', U.token, { id: c4.id })
ok(r.json.status === 'failed' && (await credits(U.uid)) === 120, 'a job stuck for over three hours is canceled and refunded')

// stale jobs are also cleaned up when starting the next run
const c5 = clip({ prompt: 'SLOW two', genPrompt: 'SLOW two' })
await fn('generate', U.token, { clips: [c5] })
await sql(`update public.job_ledger set created_at = now() - interval '4 hours' where clip_id=$1`, [c5.id])
await sql('update public.profiles set credits=1 where id=$1', [U.uid])
r = await fn('generate', U.token, { clips: [clip()] })
ok(r.status === 200 && r.json.credits === 1 + 5 - 5, 'starting a run first refunds stale jobs, which then pays for it')

// ---------- a clip id cannot be reused to double-spend or overwrite ----------
await sql('update public.profiles set credits=50 where id=$1', [U.uid])
r = await fn('generate', U.token, { clips: [c1] })
ok(r.status === 409 && (await credits(U.uid)) === 50, 'reusing an existing clip id is refused, and nothing is charged')

// ---------- delete account ----------
const D = await signup('dana')
await fn('register-generator', null, { url: 'http://localhost:8101' }, { 'x-register-key': 'regkey' })
const dc = clip(); await fn('generate', D.token, { clips: [dc] }); await poll(D.token, dc.id)
ok((await state()).objects[`${D.uid}/${dc.id}`] > 0, '(setup) Dana has a stored video')
ok((await fn('delete-account', null, {})).status === 401, 'delete-account needs a login')
r = await fn('delete-account', D.token, {})
st = await state()
ok(r.status === 200, 'delete-account succeeds')
ok(!Object.keys(st.objects).some((k) => k.startsWith(D.uid)), 'videos removed from storage')
ok((await sql('select 1 from auth.users where id=$1', [D.uid])).length === 0 && (await sql('select 1 from public.profiles where id=$1', [D.uid])).length === 0 && (await sql('select 1 from public.clips where user_id=$1', [D.uid])).length === 0 && (await sql('select 1 from public.job_ledger where user_id=$1', [D.uid])).length === 0, 'sign-in, profile, clips and ledger all deleted')

console.log(fails ? `\n${fails} FAILED` : '\nALL FUNCTION CHECKS PASSED')
process.exit(fails ? 1 : 0)
