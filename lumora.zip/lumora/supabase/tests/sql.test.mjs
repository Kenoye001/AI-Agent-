import { PGlite } from '@electric-sql/pglite'
import fs from 'fs'
const db = new PGlite()
await db.exec(fs.readFileSync(new URL('./stubs.sql', import.meta.url), 'utf8'))
await db.exec(fs.readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'))
await db.exec(fs.readFileSync(new URL('../phase3.sql', import.meta.url), 'utf8'))
await db.exec(fs.readFileSync(new URL('../phase3.sql', import.meta.url), 'utf8')) // idempotent: second run must not fail
console.log('PASS schema.sql + phase3.sql load, and phase3.sql can be re-run')

let fails = 0
const ok = (c, m) => { console.log(c ? 'PASS' : 'FAIL', m); if (!c) fails++ }
const A = '11111111-1111-1111-1111-111111111111', B = '22222222-2222-2222-2222-222222222222'
await db.query(`insert into auth.users (id,email,raw_user_meta_data) values ($1,'a@x.com','{"name":"Ann"}'),($2,'b@x.com','{}')`, [A, B])

const as = async (role, uid, sql, params) => {
  await db.exec(`set role ${role}; select set_config('request.jwt.claim.sub','${uid ?? ''}',false)`)
  try { return (await db.query(sql, params)).rows } finally { await db.exec('reset role') }
}
const user = (uid, sql, p) => as('authenticated', uid, sql, p)
const svc = (sql, p) => as('service_role', null, sql, p)
const denied = async (label, fn, re = /permission denied|row-level security|violates|not_authenticated/i) => {
  try { await fn(); ok(false, `${label} (was allowed!)`) } catch (e) { ok(re.test(e.message), `${label} -> ${e.message.slice(0, 70)}`) }
}
const credits = async (u) => (await db.query('select credits from public.profiles where id=$1', [u])).rows[0].credits

// ---------- the browser cannot cheat ----------
await denied('user cannot raise own credits', () => user(A, `update public.profiles set credits = 99999 where id = $1`, [A]))
await denied('user cannot change own plan', () => user(A, `update public.profiles set plan = 'studio' where id = $1`, [A]))
await denied('user cannot touch refill_on', () => user(A, `update public.profiles set refill_on = '' where id = $1`, [A]))
await user(A, `update public.profiles set name = 'Ann B', settings = '{"provider":"custom"}' where id = $1`, [A])
ok((await db.query('select name from public.profiles where id=$1', [A])).rows[0].name === 'Ann B', 'user CAN edit name and settings')
await denied('user cannot insert a profile', () => user(A, `insert into public.profiles (id, credits) values (gen_random_uuid(), 5000)`))
await denied('user cannot delete own profile', () => user(A, `delete from public.profiles where id = $1`, [A]), /./)
ok((await db.query('select 1 from public.profiles where id=$1', [A])).rows.length === 1, 'profile still exists after the delete attempt')
await denied('user cannot read the job ledger', () => user(A, `select * from public.job_ledger`))
await denied('user cannot read app_config', () => user(A, `select * from public.app_config`))
await denied('user cannot call reserve_jobs', () => user(A, `select public.reserve_jobs($1, '[]')`, [A]))
await denied('user cannot call finalize_job', () => user(A, `select public.finalize_job('x', false)`))
await denied('anon cannot call claim_daily_refill', () => as('anon', null, `select public.claim_daily_refill()`))
await denied('anon cannot read profiles', () => as('anon', null, `select * from public.profiles`))
ok((await user(B, 'select id from public.profiles')).length === 1, "user B only sees their own profile")

// ---------- daily refill ----------
let r = (await user(A, `select public.claim_daily_refill() as r`))[0].r
ok(r.credits === 120 && r.plan === 'free', 'first refill of the day gives the daily credits')
await db.query(`update public.profiles set credits = 4 where id = $1`, [A])
r = (await user(A, `select public.claim_daily_refill() as r`))[0].r
ok(r.credits === 4, 'second claim the same day gives nothing (cannot farm credits)')
await db.query(`update public.profiles set refill_on = '2000-01-01' where id = $1`, [A])
r = (await user(A, `select public.claim_daily_refill() as r`))[0].r
ok(r.credits === 120, 'next day tops up to the daily amount')

// ---------- reserving jobs ----------
const job = (id, dur = 5, model = 'flow') => ({ id, model, duration: dur, data: { prompt: 'p', imageDataUrl: 'data:big', status: 'done', cost: 0 } })
const reserve = (u, jobs) => svc(`select public.reserve_jobs($1, $2::jsonb) as c`, [u, JSON.stringify(jobs)])
ok((await reserve(A, [job('clipaaaa1', 5)]))[0].c === 115, 'reserve charges 1 credit per second (5s flow = 5)')
const row = (await db.query(`select data, has_video from public.clips where id='clipaaaa1'`)).rows[0]
ok(row.data.status === 'processing' && row.data.cost === 5 && row.data.hosted === true && !('imageDataUrl' in row.data), 'server forces status=processing and cost, strips the image')
await denied('insufficient credits is refused', () => reserve(A, [job('clipaaaa2', 5), job('clipaaaa3', 5), job('clipaaaa4', 5), job('clipaaaa5', 5)]), /plan_limit|insufficient/)
await db.query(`update public.profiles set credits = 8 where id = $1`, [A])
await denied('cost above balance is refused', () => reserve(A, [job('clipaaaa2', 5), job('clipaaaa3', 5)]), /insufficient_credits/)
ok(await credits(A) === 8, 'a refused run charges nothing (atomic)')
ok((await db.query(`select 1 from public.clips where id in ('clipaaaa2','clipaaaa3')`)).rows.length === 0, 'a refused run leaves no rows behind')
await denied('max clip length is 60s', () => reserve(A, [job('clipaaaa7', 61)]), /plan_limit/)
await denied('free plan max 2 clips per run', () => reserve(A, [job('cliplim01', 1), job('cliplim02', 1), job('cliplim03', 1)]), /plan_limit/)
await denied('bad clip id (path traversal) is refused', () => reserve(A, [job('../../x', 1)]), /bad_request/)
await denied('bad duration is refused', () => reserve(A, [job('clipaaaa8', -3)]), /plan_limit/)
await denied('unknown model is refused', () => reserve(A, [job('clipaaaa9', 3, 'gold')]), /bad_request/)
await denied('reusing a clip id is refused', () => reserve(A, [job('clipaaaa1', 1)]), /duplicate|unique/)
ok(await credits(A) === 8, 'none of the refused runs charged anything')

// ---------- refunds happen once, only via the server ----------
await db.query(`update public.profiles set credits = 40 where id = $1`, [A])
ok((await reserve(A, [job('cinecl001', 5, 'cine')]))[0].c === 30, 'everyone can use Cine (2 per second: 5s = 10)')
let c = (await svc(`select public.finalize_job('cinecl001', false, 'boom') as c`))[0].c
ok(c === 40, 'failed job refunds the full cost')
c = (await svc(`select public.finalize_job('cinecl001', false, 'boom') as c`))[0].c
ok(c === 40, 'finalizing again does NOT refund twice')
c = (await svc(`select public.finalize_job('cinecl001', true, null, true) as c`))[0].c
ok(c === 40 && (await db.query(`select state from public.job_ledger where clip_id='cinecl001'`)).rows[0].state === 'refunded', 'a refunded job cannot later be marked done')
ok((await db.query(`select data from public.clips where id='cinecl001'`)).rows[0].data.status === 'failed', 'clip row shows failed with the error')

await reserve(A, [job('goodclip01', 5)])
const before = await credits(A)
await svc(`select public.finalize_job('goodclip01', true, null, true)`)
ok(await credits(A) === before, 'successful job keeps the charge')
const g = (await db.query(`select data, has_video from public.clips where id='goodclip01'`)).rows[0]
ok(g.data.status === 'done' && g.has_video === true && g.data.hasVideo === true, 'successful clip is marked done with a video')
await svc(`select public.finalize_job('goodclip01', false, 'late failure')`)
ok(await credits(A) === before, 'a finished job cannot be turned into a refund afterwards')

// forged ledger: user fakes a processing clip with a huge cost, then no refund is possible
await user(A, `insert into public.clips (id,user_id,data) values ('forged0001',$1,'{"status":"processing","cost":100000}')`, [A])
await denied('finalize on a forged clip row finds no ledger entry', () => svc(`select public.finalize_job('forged0001', false)`), /unknown_job/)

// stale jobs
await reserve(A, [job('stale00001', 5)])
await db.query(`update public.job_ledger set created_at = now() - interval '2 hours' where clip_id='stale00001'`)
const b4 = await credits(A)
ok((await svc(`select public.refund_stale_jobs($1, 30) as n`, [A]))[0].n === 1 && await credits(A) === b4 + 5, 'stale running jobs are refunded')

// ---------- cross-user isolation of the new data ----------
ok((await user(B, `select id from public.clips`)).length === 0, 'user B cannot see user A\'s hosted clips')

console.log(fails ? `\n${fails} FAILED` : '\nALL SQL CHECKS PASSED')
process.exit(fails ? 1 : 0)
